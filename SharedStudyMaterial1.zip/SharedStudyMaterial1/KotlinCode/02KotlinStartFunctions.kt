
/*
kotlinc 02KotlinStartFunctions.kt -include-runtime -d startfunctions.jar
java -jar startfunctions.jar
*/

package learnKotlin

// _____________________________________________________
// Experiment Folloiwng Code, Moment Done RAISE HAND!

// Function which Doesn't Takes Any Aruguments And 
// Return Unit value of Unit Type
fun helloWorld() {
	println("Hello World!!!")
}

// Function Takes 2 Arguments of Int Type and Return One Value of Int Type
fun maximum(a: Int, b: Int) : Int {
	return if (a > b) a else b 
}

fun playWithMaximum() {
	var result: Int

	result = maximum(100, 200)
	println("Maxumum value: $result")
	result = maximum(100, -100)
	println("Maxumum value: $result")
}

// _____________________________________________________
// Experiment Folloiwng Code, Moment Done RAISE HAND!

// Function Take 1 Argument and Return Unit Value of Unit Type
fun printMultipleOfFive(value: Int) {
    println("$value * 5 = ${value * 5}")
}

// Function Take 2 Argument and Return Unit Value of Unit Type
fun printMultipleOf(multiplier: Int, andValue: Int) {
    println("$multiplier * $andValue = ${multiplier * andValue}")
}

// Function Take 2 Argument and Return Unit Value of Unit Type
// Second Argument Have Default Value
fun printMultipleOfDefaultValue(multiplier: Int, value: Int = 1) {
    println("$multiplier * $value = ${multiplier * value}")
}

fun playWithFunctionArguments() {
	printMultipleOfFive(10)
	printMultipleOf(multiplier = 4, andValue = 2)

	printMultipleOfDefaultValue(4, 2)
	printMultipleOfDefaultValue(4)
}

// _____________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// Following Functions multiply and multiplyInferred are same
fun multiply(number: Int, multiplier: Int): Int {
    return number * multiplier
}

// Return Type of Following Function Is Inferred From RHS Expression Type
// number and mutliplier is Int Type and product will also be of Int Type
// Hence return type of function will be Int
fun multiplyInferred0(number: Int, multiplier: Int) = number * multiplier

// Explicitly Specified Return Type Int
fun multiplyInferred1(number: Int, multiplier: Int): Int = number * multiplier

fun multiplyAndDivide(number: Int, factor: Int): Pair<Int, Int> {
    return Pair(number * factor, number / factor)
}

fun playWithFunctionReturnValues() {
	var result: Int

	result = multiply(4, 2)
	println(result)

	result = multiplyInferred0(4, 2)
	println(result)
	result = multiplyInferred1(4, 2)
	println(result)

	val (product, quotient) = multiplyAndDivide(4, 2)
	println("Product : $product, Quotient: $quotient")
}

// _____________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

//  Parameters as values
//  By Default Arguments are val i.e. Immutable/Constant
 fun incrementAndPrint(value: Int): Int {
   //value += 1 // error: val cannot be reassigned
   val newValue = value + 1
   return newValue
 }

fun playWithIncrementAndPrint() {
	var value = 10
	println(value)
	value = incrementAndPrint(value)
	println(value)
}

// _____________________________________________________

// Function Overloading
//		Functions With Same Names
//		With Different Arguments Types or Argument Numbers	
// getValue Function Overloaded Based On Type Of Arguments
fun getValue(value: Int): Int {
    return value + 1
}

fun getValue(value: String): String {
    return "The value is $value"
}

fun playWithGetValue() {
    val valueInt: Int = getValue(42)
    val valueString: String = getValue("Galloway")
    println(valueInt)
    println(valueString)
}

// add Function Overloaded Based On Number Of Arguments
fun add(a: Int, b: Int) : Int {
	return a + b
}

fun add(a: Int, b: Int, c: Int) : Int {
	return a + b + c
}

fun playWithOverloadedSum() {
	var result : Int

	result = add( 100, 200 )
	println("Total : $result")

	result = add( 100, 200, 400 )
	println("Total : $result")
}

// _____________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// addition Function Has Type
// Function Type (Int, Int) -> Int
// fun addition(a: Int, b: Int) : Int {
// 	return a + b
// }

// substraction Function Has Type
// Function Type (Int, Int) -> Int
// fun substraction(a: Int, b: Int) : Int {
// 	return a - b
// }

fun playWithFunctionReferences() {
	val xx: Int = 100
	val yy: Int = 200
	var result: Int

	result = addition(xx, yy)
	println("Result : $result")

	result = substraction(xx, yy)
	println("Result : $result")

	// error: type mismatch: inferred type is KFunction2<Int, Int, Int> 
	// but Int was expected
//	var operation: Int = ::addition // ::addtion is Reference of Function addition

	// ::addtion is Reference of Function addition	
	var operation: (Int, Int) -> Int = ::addition 
	result = operation(xx, yy)
	println("Result : $result")

	// ::substraction is Reference of Function substraction
	operation = ::substraction 
	result = operation(xx, yy)
	println("Result : $result")
}

// _____________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// addition Function Has Type
// Function Type (Int, Int) -> Int
fun addition(a: Int, b: Int) : Int {
	return a + b
}

// addition Function Has Type
// Function Type (Int, Int, Int) -> Int
fun addition3(a: Int, b: Int, c: Int) : Int {
	return a + b + c
}

// substraction Function Has Type
// Function Type (Int, Int) -> Int
fun substraction(a: Int, b: Int) : Int {
	return a - b
}

fun multiplication(a: Int, b: Int) : Int {
	return a * b
}

// Calculator Is Function
// Which Takes One Function As Argument
// (Int, Int, (Int, Int) -> Int ) -> Int
fun calcualator(x: Int, y: Int, operation: (Int, Int) -> Int ) : Int {
	val result = operation(x, y)
	return result
}

fun playWithCalculator() {
	val xx: Int = 100
	val yy: Int = 200
	var result: Int

	result = calcualator(xx, yy, ::addition)
	println("Result : $result")	

	result = calcualator(xx, yy, ::substraction)
	println("Result : $result")	

	result = calcualator(xx, yy, ::multiplication)
	println("Result : $result")	

	// error: type mismatch: inferred type is KFunction3<Int, Int, Int, Int> 
	// but (Int, Int) -> Int was expected

	// result = calcualator(xx, yy, ::addition3)
	// println("Result : $result")	
}

// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________

fun main() {
	println("Function : playWithMaximum")
	playWithMaximum()

	println("Function : playWithFunctionArguments")
	playWithFunctionArguments()

	println("Function : playWithFunctionReturnValues")
	playWithFunctionReturnValues()

	println("Function : playWithIncrementAndPrint")
	playWithIncrementAndPrint()

	println("Function : playWithGetValue")
	playWithGetValue()

	println("Function : playWithOverloadedSum")
	playWithOverloadedSum()

	println("Function : playWithFunctionReferences")
	playWithFunctionReferences()

	println("Function : playWithCalculator")
	playWithCalculator()

	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
}
