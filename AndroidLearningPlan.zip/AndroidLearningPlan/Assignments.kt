
DAY 01
____________________________________________________________

	A1.1 Kotlin Code [ MUST ]
		 Practice and Revise Kotlin Code Done Till Nwo

	A1.2 Kotlin Study Notes [ MUST ]
		 KotlinNotes2-6.Shared.pdf


DAY 02
____________________________________________________________
	
	A2.1 Kotlin Code [ MUST ]
		 Practice and Revise Kotlin Code Done Till Nwo

	A2.2 Kotlin Study Notes [ MUST ]
		 KotlinNotes2-6.Shared.pdf
		 KotlinNotes2.Shared.pdf

DAY 03
____________________________________________________________

	A3.0 Previous Pending Reading And Code Practice Assignments

	A3.1 Kotlin Study Notes [ MUST ]
		 KotlinNotes3.Shared.pdf
		 KotlinNotes4.Shared.pdf

	A3.2 Kotlin Code [ MUST ]
		 Practice and Revise Kotlin Code Done Till Nwo

DAY 04
____________________________________________________________

	A4.0 REVISE ALL KOTLIN NOTES AND CODE PRACTICE [MUST]
		 KotlinNotes2-6.Shared.pdf
		 KotlinNotes2.Shared.pdf
		 KotlinNotes3.Shared.pdf
		 KotlinNotes4.Shared.pdf	

	A4.1 Kotlin Study Notes [ MUST ]
		 KotlinNotes5.Shared.pdf
		 KotlinNotes6.Shared.pdf

	A4.2 Kotlin Code [ MUST ]
		 Practice and Revise Kotlin Code Done Till Now

	A4.3 Read And Practice C Code [MUST ]
	 		Chapter 4 : Functions And Program Structure
	 		Chapter 5 : Pointers And Arrays
	 			The C Programming Langugage, 2nd Edition, By Dennish Ritchie

	A4.4 Reading And Understanding Assignments [ GODD TO HAVE ]
		 Chapter 09: Tables And Information Retrieval
		 		Data Structure And Program Design, By Robert L. Kruse
		 
DAY 05
____________________________________________________________

	A5.1 Kotlin Study Notes [ MUST ]
		 KotlinNotes7.Shared.pdf
		 KotlinNotes8.Shared.pdf
		 KotlinNotes9.Shared.pdf

	A5.2 Kotlin Code [ MUST ]
		 Practice and Revise Kotlin Code Done Till Now

	A5.3 Read And Practice C Code [MUST ]
 		Chapter 5 : Pointers And Arrays
 			The C Programming Langugage, 2nd Edition, By Dennish Ritchie

	A5.4 Reading And Understanding Assignments [ GODD TO HAVE ]
		 Chapter 09: Tables And Information Retrieval
		 		Data Structure And Program Design, By Robert L. Kruse

DAY 06
____________________________________________________________

	A6.1 Kotlin Study Notes [ MUST ]
		 KotlinNotes10.Shared.pdf
		 KotlinNotes11.Shared.pdf

	A6.2 Kotlin Code [ MUST ]
		 Practice And Revise Kotlin Code Done Till Now

	A6.3 Kotlin Programming Assignments [ MUST ]
		Q1. Implement Binary Search Algorithm In Kotlin Language
		Q2. Implement Insertion Sort Algorithm In Kotlin
		Q3. Simulate Following Things In Kotlin Using Classes/Functions/Enums etc...
			 Student Register For Courses
			 Teaches Teaches Courses

	A6.4 Read And Practice C Code [MUST ]
 		Chapter 5 : Pointers And Arrays
 			The C Programming Langugage, 2nd Edition, By Dennish Ritchie


DAY 07
____________________________________________________________

	A7.1 Kotlin Study Notes [ MUST ]
		 KotlinNotes13.Shared.pdf
		 KotlinNotes14.Shared.pdf

	A7.2 Kotlin Code [ MUST ]
		 Practice And Revise Kotlin Code Done Till Now

	A7.3 Kotlin Programming Assignments [ MUST ]
		Q3. Simulate Following Things In Kotlin Using Classes/Functions/Enums etc...
			 Student Register For Courses
			 Teacher Teaches Courses
			 Institute Runs Programs
			 Programs Have Courses

DAY 08
____________________________________________________________

	A8.1 Kotlin Study Notes [ MUST ]
		REVISE EVERYTHING

	A8.2 Kotlin Code [ MUST ]
		 Practice And Revise Kotlin Code Done Till Now
		 COMPLETE CODE EXAMPLES WHICH ARE PARTICIALS
		15.KotlinAdvancedClasses.kt
		20.KotlinExceptions.kt
		21.KotlinFunctionalProgramming.kt

	A8.3 Kotlin Programming Assignments [ MUST ]
		Q3. Simulate Following Things In Kotlin Using Classes/Functions/Enums etc...
			 Student Register For Courses
			 Teacher Teaches Courses
			 Institute Runs Programs
			 Programs Have Courses

DAY 09
____________________________________________________________

	A9.0 REVISE KOTLIN STUDY NOTES AND CODE EXAMPLES [ MUST ]
		REVISE ALL KOTLIN NOTES AND CODE EXAMPLESEVERYTHING

	A9.1 Study Kotlin Notes [ MUST ]
	    KotlinNotes12.Shared.pdf

	A9.2 Kotlin Code [ MUST ]
		 Practice And Revise Kotlin Code Done EARLIER ALSO
		 COMPLETE ALL CODE EXAMPLES WHICH ARE INCOMPLETE
		
		15.KotlinAdvancedClasses.kt
		10KotlinMoreDownloader.kt
		16.DowloaderCombined.kt		
		20.KotlinExceptions.kt
		21.KotlinFunctionalProgramming.kt
|   	22.KotlinOperatorOverloading.kt

|   	18.KotlinGenerics.kt

	A9.3 Kotlin Programming Assignments [ MUST ]
		Q3. Simulate Following Things In Kotlin Using Classes/Functions/Enums etc...
			 Student Register For Courses
			 Teacher Teaches Courses
			 Institute Runs Programs
			 Programs Have Courses

	A9.4 Android Presenttations [ MUST ]
		01.0 Introduction to Android.pdf
		01.1 Your first Android app.pdf

	A9.5 Android Reading Assignments [ MUST ]
		https://developer.android.com/guide/platform

	A9.6 Android Code Practice [ MUST ]
		EmpptyActivity


DAY 10
____________________________________________________________


	KotlinNotes5.Shared.pdf
		Challenge 1
		Challenge 2

	KotlinNotes6.Shared.pdf
		Challenges 

	KotlinNotes7.Shared.pdf
		Challenge 1
		Challenge 2



DAY 11
____________________________________________________________

`-- AndroidNotesAndPresentations
    |-- 01.2 Layouts and resources for the UI.pdf
    |-- AndroidNotes4.1-2.pdf
    `-- AndroidNotes4.3.pdf

	|-- AndroidCode
	|-- AndroidKotlin4.Code1.zip



DAY 12
____________________________________________________________

	A12.1 Understand And Explore Android Code Examples [ MUST ]
		|-- AndroidNotes
		|   |-- 01.CreatingApplicationsAndActivities.Share.pdf
		|   `-- 02.BuildingUserInterfaces.Share.pdf

		`-- AndroidPresentations
		    |-- 01.2 Layouts and resources for the UI.pdf
		    |-- 01.3 Text and scrolling views.pdf
		    |-- 01.4 Resources to help you learn.pdf
		    |-- 02.1 Activities and Intents.pdf
		    `-- 02.2 Activity lifecycle and state.pdf


	A12.2 Understand And Explore Android Code Examples [ MUST ]

		Exploring And Understanding Excercise!

			Download Link : https://github.com/techhue/IBM.Android.July2021
			Download Android.Code2.Shared.zip and Unzip It

			Explore Following Examples, Build and Run!
				.
				`-- Project.04
				    |-- Project.04.01.Layouts
				    `-- Project.04.04.Adapters  

		Exploring And Understanding Excercise!

			Download Link : https://github.com/techhue/IBM.Android.July2021
			Download Android.Code.Fragments.zip and Unzip It

			Explore Following Examples, Build and Run!
				.
				|-- Android.Code.Fragments
				|   `-- AndroidFundamentals
				|-- Android.Code.Fragments
				|   |-- AndroidFragmentFundamentals		
				|   |-- AndroidFragmentPizza


	A12.3 Revise And Explore Android Code Examples [ MUST ]
		
		Exploring And Understanding Excercise!

			Download Link : https://github.com/techhue/IBM.Android.July2021
			Download Android.Code1.zip and Unzip It

			Explore Following Examples, Build and Run!

			`-- Project.03
			    |-- Project.03.03.ConfigChanges
			    |-- Project.03.04.Activities


DAY 13
____________________________________________________________

	A13.1 Complete Study Material Part 1 [ MUST ]
		|-- AndroidNotes
		|   |-- 01.CreatingApplicationsAndActivities.Share.pdf
		|   `-- 02.BuildingUserInterfaces.Share.pdf

		`-- AndroidPresentations
		    |-- 01.2 Layouts and resources for the UI.pdf
		    |-- 01.3 Text and scrolling views.pdf
		    |-- 01.4 Resources to help you learn.pdf
		    |-- 02.1 Activities and Intents.pdf
		    `-- 02.2 Activity lifecycle and state.pdf

	A13.2 Complete Study Material Part 2 [ MUST ]

		|-- AndroidPresentationsStudy
		    |-- 03.1 The Android Studio debugger.pdf
		    |-- 04.1 Buttons and clickable images.pdf
		    |-- 04.2 Input controls.pdf
		    |-- 04.4 User navigation.pdf
		    |-- 04.5 RecyclerView.pdf
		    |-- 05.1 Drawables, styles, and themes.pdf
		    `-- 05.3 Resources for adaptive layouts.pdf

		|-- AndroidNotesStudy
		|   `-- 03.IntentsAndBroadcastReceivers.Share.pdf


	A13.3 Explore Android Code Examples [ MUST ]

		|-- AndroidCodeExplore
		|   `-- Android.Code3
		|       `-- Project.05
		|           `-- Project.05.01.Intents


	A13.4 Revise And Explore Android Code Examples [ MUST ]
		.
		|-- AndroidCodeCommentedRevise
		|   |-- Android.Code.Fragments
		|   |   |-- AndroidFragmentFundamentals
		|   |   |-- AndroidFragmentPizza
		|   |   `-- AndroidFundamentals
		|   |       
		|   `-- Android.Code2
		|       `-- Project.04
		|           |-- Project.04.01.Layouts
		            `-- Project.04.04.Adapters


DAY 14
____________________________________________________________


	A14.1 Complete Study Material Part  [ MUST ]
	
		|-- AndroidPresentationsStudy
		    |-- 01.0 Introduction to Android.pdf
		    |-- 01.1 Your first Android app.pdf
		    |-- 01.2 Layouts and resources for the UI.pdf
		    |-- 01.3 Text and scrolling views.pdf
		    |-- 01.4 Resources to help you learn.pdf
		    |-- 02.1 Activities and Intents.pdf
		    |-- 02.2 Activity lifecycle and state.pdf
		    |-- 02.3 Implicit Intents.pdf
		    |-- 03.1 The Android Studio debugger.pdf
		    |-- 03.2 App testing.pdf
		    |-- 03.3 The Android Support Library.pdf
		    |-- 04.1 Buttons and clickable images.pdf
		    |-- 04.2 Input controls.pdf
		    |-- 04.3 Menus and pickers.pdf
		    |-- 04.4 User navigation.pdf
		    |-- 04.5 RecyclerView.pdf
		    |-- 05.1 Drawables, styles, and themes.pdf
		    |-- 05.2 Material Design.pdf
		    |-- 05.3 Resources for adaptive layouts.pdf
		    |-- 07.1 AsyncTask and AsyncTaskLoader.pdf
		    |-- 07.2 Internet connection.pdf
		    |-- 07.3 Broadcasts.pdf
		    |-- 07.4 Services.pdf
		    |-- 08.1 Notifications.pdf
		    `-- 08.2 Alarms.pdf

		|-- AndroidNotesStudy
			|   `-- 03.IntentsAndBroadcastReceivers.Share.pdf
			
	A14.2 Revise And Explore Android Code Examples [ MUST ]

		|-- AndroidCodeCommentedRevise
		|   |-- AndroidServicesDemo


	A14.3 Explore Following Code Examples  [ MUST ]

		Complete These Code Examples With More Features
		Fix Any Errors Any Code

		|-- AndroidKotlinCode
		|   `-- AndroidKotlin.Code1
		|       |-- Project.03.01.ManifestAndResourses - Working
		|       |-- Activities 		- Working
		|       |-- Layouts    		- Working
		|       |-- Adapters   		- Working

		|       |-- ConfigChanges 	- Working
		|       |-- Intents       	- Working
		
		|       |-- BoadCastIntent 	- Working	
		|       |-- Internet
		|       `-- Views


		Do Following Changes In These Files 
			gradle.build Project Level File
			gradle.build App Module Level File
			gradle-wrapper.properties File
		__________________________________________
			// Gradle.Build Project Level File

			buildscript {
			    ext.kotlin_version = "1.5.10"
			    repositories {
			        google()
			        mavenCentral()
			    }
			    dependencies {
			        classpath "com.android.tools.build:gradle:4.2.1"
			        classpath "org.jetbrains.kotlin:kotlin-gradle-plugin:$kotlin_version"
			    }
			}

			allprojects {
			    repositories {
			        google()
			        mavenCentral()
			    }
			}
			__________________________________________
			// Gradle.Build App Module Level File

			android {
			    compileSdkVersion 30
			    buildToolsVersion "30.0.3"

			    defaultConfig {
			        minSdkVersion 27
			        targetSdkVersion 30
			    }
			__________________________________________
			// Gradle > gradle-wrapper.properties File

			distributionBase=GRADLE_USER_HOME
			distributionUrl=https\://services.gradle.org/distributions/gradle-6.7.1-bin.zip
			distributionPath=wrapper/dists
			zipStorePath=wrapper/dists
			zipStoreBase=GRADLE_USER_HOME



DAY 15 [ WEEKEND ASSIGNMENTS ]
____________________________________________________________


	A15.1 Complete Study Material Part  [ MUST ]
	
		|-- AndroidPresentationsStudy

		    |-- 01.0 Introduction to Android.pdf
		    |-- 01.1 Your first Android app.pdf
		    |-- 01.2 Layouts and resources for the UI.pdf
		    |-- 01.3 Text and scrolling views.pdf
		    |-- 01.4 Resources to help you learn.pdf
		    |-- 02.1 Activities and Intents.pdf
		    |-- 02.2 Activity lifecycle and state.pdf
		    |-- 02.3 Implicit Intents.pdf
		    |-- 03.1 The Android Studio debugger.pdf
		    |-- 03.2 App testing.pdf
		    |-- 03.3 The Android Support Library.pdf
		    |-- 04.1 Buttons and clickable images.pdf
		    |-- 04.2 Input controls.pdf
		    |-- 04.3 Menus and pickers.pdf
		    |-- 04.4 User navigation.pdf
		    |-- 04.5 RecyclerView.pdf
		    |-- 05.1 Drawables, styles, and themes.pdf
		    |-- 05.2 Material Design.pdf
		    |-- 05.3 Resources for adaptive layouts.pdf
		    |-- 07.1 AsyncTask and AsyncTaskLoader.pdf
		    |-- 07.2 Internet connection.pdf
		    |-- 07.3 Broadcasts.pdf
		    |-- 07.4 Services.pdf
		    |-- 08.1 Notifications.pdf
		    |-- 08.2 Alarms.pdf
		    |-- 08.3 Efficient data transfer and JobScheduler.pdf
		    |-- 09.0 Data Storage.pdf
		    |-- 09.1 Shared Preferences.pdf
		    |-- 09.2 App settings.pdf
		    |-- 10.0 SQLite Primer.pdf
		    `-- 10.1 Room, LiveData, and ViewModel.pdf


	A15.2 Revise And Explore Android Code Examples [ MUST ]

		|-- AndroidJava.Code
		|   |-- Android.Code3
		|   |   `-- Android.Code3
		|   |       `-- Project.05
		|   |           |-- Project.05.01.Intents
		|   |           |-- Project.05.02.Linkify
		|   |           `-- Project.05.03.BoadcastIntents
		|   `-- Android.Code4
		|       `-- Android.Code4
		|           `-- Project.06
		|               `-- Project.06.01.Internet
		|-- AndroidCodeCommentedRevise
		|   |-- AndroidServicesDemo


	A15.3 Explore Following Code Examples  [ MUST ]

		Complete These Code Examples With More Features
		Fix Any Errors Any Code

		|-- AndroidKotlinCode
		|   `-- AndroidKotlin.Code1
		|       |-- Activities
		|       |-- Adapters
		|       |-- BroadcastIntent
		|       |-- ConfigChanges
		|       |-- Intents
		|       |-- Internet
		|       |-- Layouts
		|       |-- Project.03.01.ManifestAndResourses
		|       `-- Views



	A15.4 CODING ASSIGNMENT [ MUST MUST MUST ]

		CODE FOLLOWING EXAMPLE IN KOTLIN AND MAKE IT WORKING
		DON"T COPY PASTE

		CODE AndroidIntroduction IN KOTLIN
		
		.
		|-- AndroidCodingAssignment
		|   `-- Android.Code.Funamentals
		|       |-- AndroidIntroduction
		|


	A15.5 CODING ASSIGNMENT [ MUST MUST MUST ]

		STUDY FOLLWOING TUTORIAL AND CODE EXAMPLE IN KOTLIN DONE IN FOLLOWING CODING LAB
		Codelabs for Android Kotlin Fundamentals
			https://developer.android.com/courses/kotlin-android-fundamentals/overview
			https://developer.android.com/courses/kotlin-android-fundamentals/toc

		CODE FOLLWOING CODINGLAB CHAPTERS IN KOTLIN 

			Lesson 1: Build your first app
				1.0 Install Android Studio
				1.1 Get started
				1.2 Basic app anatomy
				1.3 Image resources and compatibility
				1.4 Learn to help yourself

			Lesson 2: Layouts
				2.1 Linear layout using the Layout Editor
				2.2 Add user interactivity
				2.3 Constraint layout using the Layout Editor
				2.4 Data-binding basics

			Lesson 3: Navigation
				3.1 Create a fragment
				3.2 Define navigation paths
				3.3 Start an external activity

			Lesson 4: Activity and Fragment Lifecycles
				4.1 Lifecycles and logging
				4.2 Complex lifecycle situations



	A15.6 Additional Reference Reading Material [ GOOD TO HAVE ]

			https://developer.android.com/guide/components/fundamentals
			https://developer.android.com/guide/components/intents-filters

			https://developer.android.com/guide/topics/ui/declaring-layout
			https://developer.android.com/guide/topics/ui/layout/linear
			https://developer.android.com/guide/topics/ui/layout/relative
			https://developer.android.com/training/constraint-layout
			
			https://developer.android.com/guide/components/activities/intro-activities
			https://developer.android.com/guide/components/activities/activity-lifecycle
			https://developer.android.com/guide/components/activities/state-changes
			
			https://developer.android.com/guide/fragments
			https://developer.android.com/guide/fragments/lifecycle

			https://medium.com/androiddevelopers/the-android-lifecycle-cheat-sheet-part-i-single-activities-e49fd3d202ab
			https://medium.com/androiddevelopers/the-android-lifecycle-cheat-sheet-part-ii-multiple-activities-a411fd139f24
			https://medium.com/androiddevelopers/the-android-lifecycle-cheat-sheet-part-iii-fragments-afc87d4f37fd
			https://medium.com/androiddevelopers/the-android-lifecycle-cheat-sheet-part-iv-49946659b094

			https://developer.android.com/guide/components/services



DAY 16 [ MONDAY ONWRDS...]
____________________________________________________________


	A16.1 CODING ASSIGNMENT [ MUST MUST MUST ]

		STUDY FOLLWOING TUTORIAL AND CODE EXAMPLE IN KOTLIN DONE IN FOLLOWING CODING LAB
		Codelabs for Android Kotlin Fundamentals
			https://developer.android.com/courses/kotlin-android-fundamentals/overview
			https://developer.android.com/courses/kotlin-android-fundamentals/toc

		CODE FOLLWOING CODINGLAB CHAPTERS IN KOTLIN 

			Lesson 5: Architecture components
				5.1 ViewModel and ViewModelProvider
				5.2 LiveData and LiveData observers
				5.3 DataBinding with ViewModel and LiveData
				5.4 LiveData transformations

				Sabyasachi

			Lesson 6: Room database and coroutines
				6.1 Create a Room database
				6.2 Coroutines and Room
				6.3 Record quality and button states

				Except Maithari All Are Doing This...	

			Lesson 7: RecyclerView
				7.1 RecyclerView fundamentals
				7.2 DiffUtil and data binding with RecyclerView
				7.3 GridLayout with RecyclerView
				7.4 Interacting with RecyclerView items
				7.5 Headers in RecyclerView

			Lesson 8: Connecting to the internet
				8.1 Getting data from the internet
				8.2 Loading and displaying images from the internet
				8.3 Filtering and detail views with internet data

			Lesson 9: Repository
				9.1 Repository
				9.2 WorkManager

			Lesson 10: Designing for everyone
				10.1 Styles and themes
				10.2 Material Design, dimens, and colors
				10.3 Design for everyone


	A16.2 CODING ASSIGNMENT [ MUST MUST MUST ]

		CODE FOLLOWING EXAMPLE IN KOTLIN AND MAKE IT WORKING
		DON"T COPY PASTE

		CODE AndroidIntroduction IN KOTLIN
				.
		|-- AndroidCodingAssignment
		|   `-- Android.Code.Funamentals
		|       |-- AndroidIntroduction
		|


		Reading Material
			https://developer.android.com/guide/components/fundamentals
			https://developer.android.com/guide/components/intents-filters

			https://developer.android.com/guide/topics/ui/declaring-layout
			https://developer.android.com/guide/topics/ui/layout/linear
			https://developer.android.com/guide/topics/ui/layout/relative
			https://developer.android.com/training/constraint-layout
			
			https://developer.android.com/guide/components/activities/intro-activities
			https://developer.android.com/guide/components/activities/activity-lifecycle
			https://developer.android.com/guide/components/activities/state-changes
			
			https://developer.android.com/guide/fragments
			https://developer.android.com/guide/fragments/lifecycle

			https://medium.com/androiddevelopers/the-android-lifecycle-cheat-sheet-part-i-single-activities-e49fd3d202ab
			https://medium.com/androiddevelopers/the-android-lifecycle-cheat-sheet-part-ii-multiple-activities-a411fd139f24
			https://medium.com/androiddevelopers/the-android-lifecycle-cheat-sheet-part-iii-fragments-afc87d4f37fd
			https://medium.com/androiddevelopers/the-android-lifecycle-cheat-sheet-part-iv-49946659b094

			https://developer.android.com/guide/components/services


	
NEXT 10 DAYS WORK AND LEARNING
____________________________________________________________


	A17.0 REVISE FOLLOWING LESSIONS[ MUST MUST MUST ]
		KOTLIN NOTES 
		KOLTIN CODE EXAMPLES


	A17.1  READ  AND COMPLETE FOLLOWING 3 PROJECTS
		Android Apprentice, 4th Edition
			First 27 Chapters Till Page 671
		READ and COMPLETE FOLLOWING 3 PROJECT
			ToDO List App
 			Map App
 			PodCast Player


	A17.2 REVISE FOLLOWING LESSIONS[ MUST MUST MUST ]
		REVISE FOLLOWING LESSIONS

		LEARN MORE SECTION
			READ EVERYTHING THROUGHLY AND ALL THE ARTICLES MENTIONED IN LEARN MORE SECTION


		STUDY FOLLWOING TUTORIAL AND CODE EXAMPLE IN KOTLIN DONE IN FOLLOWING CODING LAB
		Codelabs for Android Kotlin Fundamentals
			https://developer.android.com/courses/kotlin-android-fundamentals/overview
			https://developer.android.com/courses/kotlin-android-fundamentals/toc

		CODE FOLLWOING CODINGLAB CHAPTERS IN KOTLIN 

			Lesson 1: Build your first app
				1.0 Install Android Studio
				1.1 Get started
				1.2 Basic app anatomy
				1.3 Image resources and compatibility
				1.4 Learn to help yourself

			Lesson 2: Layouts
				2.1 Linear layout using the Layout Editor
				2.2 Add user interactivity
				2.3 Constraint layout using the Layout Editor
				2.4 Data-binding basics

			Lesson 3: Navigation
				3.1 Create a fragment
				3.2 Define navigation paths
				3.3 Start an external activity

			Lesson 4: Activity and Fragment Lifecycles
				4.1 Lifecycles and logging
				4.2 Complex lifecycle situations

			Lesson 5: Architecture components
				5.1 ViewModel and ViewModelProvider
				5.2 LiveData and LiveData observers
				5.3 DataBinding with ViewModel and LiveData
				5.4 LiveData transformations

			Lesson 6: Room database and coroutines
				6.1 Create a Room database
				6.2 Coroutines and Room
				6.3 Record quality and button states

			Lesson 7: RecyclerView
				7.1 RecyclerView fundamentals
				7.2 DiffUtil and data binding with RecyclerView
				7.3 GridLayout with RecyclerView
				7.4 Interacting with RecyclerView items
				7.5 Headers in RecyclerView

			Lesson 8: Connecting to the internet
				8.1 Getting data from the internet
				8.2 Loading and displaying images from the internet
				8.3 Filtering and detail views with internet data

			Lesson 9: Repository
				9.1 Repository
				9.2 WorkManager

			Lesson 10: Designing for everyone
				10.1 Styles and themes
				10.2 Material Design, dimens, and colors
				10.3 Design for everyone


	A17.3 READ FOLLOWING DEVELOPER.ANDROID.COM MATERIAL [ MUST MUST MUST ]

		Reading Material
			https://developer.android.com/guide/components/fundamentals
			https://developer.android.com/guide/components/intents-filters
			https://developer.android.com/guide/components/intents-common

			https://developer.android.com/guide/topics/ui/declaring-layout
			https://developer.android.com/guide/topics/ui/layout/linear
			https://developer.android.com/guide/topics/ui/layout/relative
			https://developer.android.com/training/constraint-layout
			

			EVERTYTHING INSIDE LOOK AND FEEL TOPIC
				https://developer.android.com/guide/topics/ui/look-and-feel
				https://developer.android.com/guide/topics/ui/look-and-feel/themes
				https://developer.android.com/guide/topics/ui/look-and-feel/darktheme
				https://developer.android.com/guide/practices/ui_guidelines/icon_design_adaptive
				AND SO ON.... 


			https://developer.android.com/guide/components/activities/intro-activities
			https://developer.android.com/guide/components/activities/activity-lifecycle
			https://developer.android.com/guide/components/activities/state-changes
			https://developer.android.com/guide/components/activities/activity-lifecycle#saras
			https://developer.android.com/guide/components/activities/tasks-and-back-stack
			https://developer.android.com/guide/components/activities/process-lifecycle
			https://developer.android.com/guide/components/activities/parcelables-and-bundles

			https://developer.android.com/guide/fragments
			https://developer.android.com/guide/fragments/create
			https://developer.android.com/guide/fragments/fragmentmanager
			https://developer.android.com/guide/fragments/transactions
			https://developer.android.com/guide/fragments/lifecycle
			https://developer.android.com/guide/fragments/animate
			https://developer.android.com/guide/fragments/saving-state
			https://developer.android.com/guide/fragments/communicate
			https://developer.android.com/guide/fragments/appbar
			https://developer.android.com/guide/fragments/dialogs

			https://medium.com/androiddevelopers/the-android-lifecycle-cheat-sheet-part-i-single-activities-e49fd3d202ab
			https://medium.com/androiddevelopers/the-android-lifecycle-cheat-sheet-part-ii-multiple-activities-a411fd139f24
			https://medium.com/androiddevelopers/the-android-lifecycle-cheat-sheet-part-iii-fragments-afc87d4f37fd
			https://medium.com/androiddevelopers/the-android-lifecycle-cheat-sheet-part-iv-49946659b094

			https://developer.android.com/guide/components/services
			https://developer.android.com/guide/components/foreground-services
			https://developer.android.com/guide/components/bound-services

			https://developer.android.com/guide/components/broadcasts

			https://developer.android.com/guide/topics/permissions/overview
			https://developer.android.com/training/permissions/evaluating
			https://developer.android.com/training/permissions/declaring
			https://developer.android.com/training/permissions/requesting
			https://developer.android.com/training/permissions/usage-notes
			https://developer.android.com/guide/topics/permissions/default-handlers
			https://developer.android.com/training/permissions/restrict-interactions

			https://developer.android.com/guide/topics/data
			https://developer.android.com/training/data-storage
			https://developer.android.com/training/data-storage/app-specific
			https://developer.android.com/training/data-storage/manage-all-files
			https://developer.android.com/training/data-storage/shared-preferences
			https://developer.android.com/training/data-storage/room
			https://developer.android.com/training/data-storage/room/defining-data
			https://developer.android.com/training/data-storage/room/accessing-data
			https://developer.android.com/training/data-storage/room/relationships
			https://developer.android.com/training/data-storage/room/async-queries
			https://developer.android.com/training/data-storage/room/creating-views
			https://developer.android.com/training/data-storage/room/prepopulate
			https://developer.android.com/training/data-storage/sqlite
			https://developer.android.com/guide/topics/providers/content-providers
			https://developer.android.com/guide/topics/providers/content-provider-basics
			https://developer.android.com/guide/topics/providers/content-provider-creating
			https://developer.android.com/guide/topics/providers/document-provider
			https://developer.android.com/guide/topics/providers/create-document-provider

			https://developer.android.com/guide/components/loaders



DAY 18
____________________________________________________________

	A18.1 REVISE FOLLOWING LESSION CODE EXAMPLES

		Lesson 5: Architecture components
			5.1 ViewModel and ViewModelProvider
			5.2 LiveData and LiveData observers
			5.3 DataBinding with ViewModel and LiveData
			5.4 LiveData transformations

		Lesson 6: Room database and coroutines
			6.1 Create a Room database
			6.2 Coroutines and Room
			6.3 Record quality and button states

		Lesson 9: Repository
			9.1 Repository
			9.2 WorkManager


FUTHRE ADVANCE LEAARNING
____________________________________________________________

		Android Architecture

			https://developer.android.com/topic/libraries/architecture
			https://developer.android.com/topic/libraries/architecture/adding-components
			https://developer.android.com/topic/libraries/app-startup


		Advanced Android Course Content
			https://developer.android.com/courses/kotlin-android-advanced/overview
			https://developer.android.com/courses/kotlin-android-advanced/toc




