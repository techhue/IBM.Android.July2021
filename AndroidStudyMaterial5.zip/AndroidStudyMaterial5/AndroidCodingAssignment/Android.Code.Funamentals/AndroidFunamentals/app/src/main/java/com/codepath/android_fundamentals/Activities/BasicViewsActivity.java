package com.codepath.android_fundamentals.Activities;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.codepath.android_fundamentals.R;

public class BasicViewsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_basic_views);
    }
}
