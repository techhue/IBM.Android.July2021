
DAY 01
____________________________________________________________

	A1.1 Kotlin Code [ MUST ]
		 Practice and Revise Kotlin Code Done Till Nwo

	A1.2 Kotlin Study Notes [ MUST ]
		 KotlinNotes2-6.Shared.pdf


DAY 02
____________________________________________________________
	
	A2.1 Kotlin Code [ MUST ]
		 Practice and Revise Kotlin Code Done Till Nwo

	A2.2 Kotlin Study Notes [ MUST ]
		 KotlinNotes2-6.Shared.pdf
		 KotlinNotes2.Shared.pdf

DAY 03
____________________________________________________________

	A3.0 Previous Pending Reading And Code Practice Assignments

	A3.1 Kotlin Study Notes [ MUST ]
		 KotlinNotes3.Shared.pdf
		 KotlinNotes4.Shared.pdf

	A3.2 Kotlin Code [ MUST ]
		 Practice and Revise Kotlin Code Done Till Nwo

DAY 04
____________________________________________________________

	A4.0 REVISE ALL KOTLIN NOTES AND CODE PRACTICE [MUST]
		 KotlinNotes2-6.Shared.pdf
		 KotlinNotes2.Shared.pdf
		 KotlinNotes3.Shared.pdf
		 KotlinNotes4.Shared.pdf	

	A4.1 Kotlin Study Notes [ MUST ]
		 KotlinNotes5.Shared.pdf
		 KotlinNotes6.Shared.pdf

	A4.2 Kotlin Code [ MUST ]
		 Practice and Revise Kotlin Code Done Till Nwo

	A4.3 Read And Practice C Code [MUST ]
	 		Chapter 4 : Functions And Program Structure
	 		Chapter 5 : Pointers And Arrays
	 			The C Programming Langugage, 2nd Edition, By Dennish Ritchie

	A4.4 Reading And Understanding Assignments [ GODD TO HAVE ]
		 Chapter 09: Tables And Information Retrieval
		 		Data Structure And Program Design, By Robert L. Kruse
		 
DAY 05
____________________________________________________________

DAY 06
____________________________________________________________

DAY 07
____________________________________________________________

DAY 08
____________________________________________________________

DAY 09
____________________________________________________________

DAY 10
____________________________________________________________


