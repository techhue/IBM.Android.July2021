
/*
kotlinc 02KotlinBasics.kt -include-runtime -d basics.jar
java -jar basics.jar
*/

package learnKotlin

fun maximum(a: Int, b: Int) : Int {
	return if (a > b) a else b 
}

fun playWithMaximum() {
	var result: Int

	result = maximum(100, 200)
	println("Maxumum value: $result")
	result = maximum(100, -100)
	println("Maxumum value: $result")
}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// Creating Person Type Having Two Properties
//		These Properties Are name and isMarried
class Person(var name: String, val isMarried: Boolean)

fun playWithPersonProperties() {
	// person Object Type Is Inferrenced From RHS i.e. Person Type
	val person = Person("Alice", true)

	// Getting Value Of Property name i.e. It's Getter Called
	println(person.name) 

	// Getting Value Of Property isMarried i.e. It's Getter Called		
	println(person.isMarried)	
	
	// Setting Value Of Property name i.e. It's Setter Called
	person.name = "Alice Carols" //

	// Getting Value Of Property name i.e. It's Getter Called
	println(person.name) 

	// Getting Value Of Property isMarried i.e. It's Getter Called		
	println(person.isMarried)	

	// person1 object Type, Explicity Annotate To Person Type
	val person1: Person = Person("Uncle Bob", false)
	println(person1.name)
	println(person1.isMarried)
	person1.name = "Bob Macmillan"

	println(person1.name)
	println(person1.isMarried)	
}

// _____________________________________________________
// Experiment Following Code, Moment Done >>> RAISE HAND!

class Rectangle(val height: Int, val width: Int) {
	val isSquare: Boolean
		get() {
			return height == width
		}
}

fun playWithRectangle() {
	val rectangle1 = Rectangle(100, 200)
	println(rectangle1.height)
	println(rectangle1.width)
	println(rectangle1.isSquare)

	val rectangle2 = Rectangle(200, 200)
	println(rectangle2.height)
	println(rectangle2.width)
	println(rectangle2.isSquare)
}


// _____________________________________________________
// Experiment Following Code, Moment Done >>> RAISE HAND!

enum class Color {
	RED, GREEN, BLUE
}

fun getStringForColor(color: Color) : String {
	return when (color) {
		Color.RED 	-> "Red Color"
		Color.GREEN -> "Green Color"
		Color.BLUE 	-> "Blue Color"
	}
}

fun playWithColors() {
	println( Color.RED )
	println( Color.GREEN )
	println( Color.BLUE )

	println( getStringForColor(Color.RED) )
	println( getStringForColor(Color.GREEN ) )
	println( getStringForColor(Color.BLUE ) )
}

// _____________________________________________________
// Experiment Following Code, Moment Done >>> RAISE HAND!

enum class Colour(val r: Int, val g: Int, val b: Int) {
	RED(255, 0, 0), GREEN(0, 255, 0), BLUE(0, 0, 255) ;

	fun rgb() = ( r * 255 + g ) * 255 + b
}

fun playWithColours() {
	println( Colour.RED )
	println( Colour.RED.r )
	println( Colour.RED.g )
	println( Colour.RED.b )
	println( Colour.RED.rgb() )

	println( Colour.GREEN )
	println( Colour.GREEN.r )
	println( Colour.GREEN.g )
	println( Colour.GREEN.b )
	println( Colour.GREEN.rgb() )

	println( Colour.BLUE )
	println( Colour.BLUE.r )
	println( Colour.BLUE.g )
	println( Colour.BLUE.b )
	println( Colour.BLUE.rgb() )
}

// _____________________________________________________
// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________

fun main() {
	println("Function : playWithMaximum")
	playWithMaximum()

	println("Function : playWithPersonProperties")
	playWithPersonProperties()

	println("Function : playWithRectangle")
	playWithRectangle()

	println("Function : playWithColors")
	playWithColors()

	println("Function : playWithColours")
	playWithColours()

	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
}
