/*
kotlinc 04KotlinClassesAndInterfaces.kt -include-runtime -d interfaces.jar
java -jar interfaces.jar
*/

package learnKotlin

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// Interface Tells What To Be Implemented
// What It WIll Do
interface Clickable {
    fun click()
}

// Classes Will Implement The Interfaces
// How, When, Where, Which Way etc.. Will Be Done By Concrete Classes
// e.g. Button is Concrete Class

class Button : Clickable { // Button Class Conforming To Clicable Interfaces
    override fun click() {
    	println("I was clicked")
    }
}

fun playWithInterface() {
    val button = Button()
    button.click()
}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

interface Clickable1 {
    fun click()
    fun showOff() { // Function With Default Implementation
    	println("I'm clickable1!")
    }
}

interface Focusable1 {
    fun setFocus(b: Boolean) { // Function With Default Implementation
        println("I ${if (b) "got" else "lost"} focus.")
    }

    fun showOff() { // Function With Default Implementation
    	println("I'm focusable1!")
    }
}

class Button1 : Clickable1, Focusable1 {
	// error: class 'Button1' is not abstract and 
	// does not implement abstract member public abstract fun click()
    // override fun click() = println("I was clicked")

    override fun click() = println("I was clicked") 

    override fun showOff() {
    	// error: many supertypes available, 
    	// please specify the one you mean in angle brackets, e.g. 'super<Foo>'
    	// super.showOff()
        super<Clickable1>.showOff()
        super<Focusable1>.showOff()
    }
}

fun playWithInterfaceClickableAndFocusable() {
    val button = Button1()
    button.showOff()
    button.setFocus(true)
    button.click()
}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// In Kotlin By Default Classes And Member Functions Are Final
// 		i.e. You CANN'T Override Them In Child Class
//		To Override Functions in Child Class You Should Explciitly Make It Open

// In Java By Default Classes And Member Functions Are Open
// 		i.e. You CAN Override Them In Child Class
//		To NOT TO Override Functions in Child Class You Should Explciitly Make It Final

open class View2 {	// Parent Class
	open fun click() {  println("View2 Got Clicked!") }
	open fun descibeMe() { println("View2 Description...") }
}
// Inheritance : Button2 Inheriting From View2
//		View2 Is Parent Class
//		Button2 Is Child Class
open class Button2 : View2() { // Creating Child Class Button2
	override fun click() { println("Button2 Got Clicked!")	}

	open fun magic() { println("Button2 Doing Magic...") }

	fun disable() = println("Disabling Button2")
}

class RichButton2 : Button2() {
	override fun descibeMe() = println("Very Rich Button... Become Rich!!!")
	override fun magic() 	= println("RichButton1 Doing Magic...")
}

fun playWithInheritance() {
	val view = View2()
	view.click() 
	view.descibeMe()

	val button = Button2()
	button.click()
	button.descibeMe()
	button.magic()
	button.disable()

	val richButton = RichButton2()
	richButton.click()
	richButton.descibeMe()
	richButton.magic()
	richButton.disable()
}


// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

open class View3 {	// Parent Class
	open fun click() {  println("View3 Got Clicked!") }
}

// Inheritance : Button3 Inheriting From View3
class Button3 : View3() { // Child Class
	override fun click() { println("Button3 Got Clicked!")	}
}
 
//Extention Function On Type View3
fun View3.showOff() 	= println("View3 Showing Off...")

//Extention Function On Type View3
fun Button3.showOff()	= println("Button3 Showing Off...")

// Extenstion Functions Doesn't Participante In Inheritance
//		i.e. Child Class Cann't Override Extension Functions
fun playWithInheritanceAndExtensionFunctions() {
	val view = View3()
	view.click() 
	view.showOff()

	val button = Button3()
	button.click()
	button.showOff()

	val viewTypeReference : View3 = Button3()
	// Will Invoke Button3.showOff() Becuase Member Function Will Participates In Inheritance
	viewTypeReference.click()		
	
	// Will Involke View3.showOff()  Because Extention Function Doesn't Participate In Inheritance
	viewTypeReference.showOff() 	
}
// Function : playWithInheritanceAndExtensionFunctions
// View3 Got Clicked!
// View3 Showing Off...
// Button3 Got Clicked!
// Button3 Showing Off...
// Button3 Got Clicked!
// View3 Showing Off...

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

interface Expression

class Num(val value: Int) : Expression
class Sum(val left:  Expression, val right: Expression) : Expression

fun eval(expression : Expression) : Int {
	// Smart Type Check
	// First Type Check Happens, If Successful Then Type Conversion
	// Here Type of expression is Expression
	//		Then Type Check With (expression is Num)
	//		expression is Num == true Than It Will Type Cast expression To Num Type 
	if ( expression is Num ) { 
		// Now Here Type of Expression is Num
		return expression.value 
	}

	// Here Type of expression is Expression
	//		Then Type Check With (expression is Sum)
	//		expression is Sum == true Than It Will Type Cast expression To Sum Type 
	if (expression is Sum) { // Type Check
		// Now Here Type of Expression is Sum
		return eval(expression.right) + eval(expression.left)
	}

	throw IllegalArgumentException("Unknown Arguments...")
}

fun playWithEvalFunction() {
	var result : Int 

	// 100 + 200
	result = eval( Sum( Num(100), Num(200) ))
	println("Result : $result")
	
	// ( 100 + 200 ) + 500
	result = eval( Sum( Sum( Num(100), Num(200) ), Num(500)) ) 
	println("Result : $result")
}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// In Kotlin if-else Contruct Is An Expression
//		Expression Means It Has Return Value

fun maximum(a: Int, b: Int) : Int {
	if ( a > b ) return a
	else return b
}

fun maximumAgain(a: Int, b: Int) : Int {
	return if ( a > b ) a else b
}

fun maximumOnceAgain(a: Int, b: Int)  = if ( a > b ) a else b

fun playWithMaximunFunction() {
	val a = 100
	val b = 200

	println( maximum( a, b ) )
	println( maximumAgain( a, b ) )
	println( maximumOnceAgain( a, b ) )
}


// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

fun evalIf(expression : Expression) : Int {
	return if ( expression is Num ) { 
		expression.value 
	} else if (expression is Sum) { 
		evalIf(expression.right) + evalIf(expression.left)
	} else {
		throw IllegalArgumentException("Unknown Arguments...")
	}
}

fun playWithEvalIfFunction() {
	var result : Int 

	// 100 + 200
	result = evalIf( Sum( Num(100), Num(200) ))
	println("Result : $result")
	
	// ( 100 + 200 ) + 500
	result = evalIf( Sum( Sum( Num(100), Num(200) ), Num(500)) ) 
	println("Result : $result")
}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

fun evalIfAgain(expression : Expression) : Int = if ( expression is Num ) { 
		expression.value 
	} else if (expression is Sum) { 
		evalIfAgain(expression.right) + evalIfAgain(expression.left)
	} else {
		throw IllegalArgumentException("Unknown Arguments...")
}


fun playWithEvalIfAgainFunction() {
	var result : Int 

	// 100 + 200
	result = evalIfAgain( Sum( Num(100), Num(200) ))
	println("Result : $result")
	
	// ( 100 + 200 ) + 500
	result = evalIfAgain( Sum( Sum( Num(100), Num(200) ), Num(500)) ) 
	println("Result : $result")
}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

fun evalWhen(expression : Expression) : Int { 
	return when ( expression ) {
 		is Num 	->  expression.value 
		is Sum  ->  evalWhen(expression.right) + evalWhen(expression.left)
		else 	->  throw IllegalArgumentException("Unknown Arguments...")
	}
}

fun playWithEvalWhenFunction() {
	var result : Int 

	// 100 + 200
	result = evalWhen( Sum( Num(100), Num(200) ))
	println("Result : $result")
	
	// ( 100 + 200 ) + 500
	result = evalWhen( Sum( Sum( Num(100), Num(200) ), Num(500)) ) 
	println("Result : $result")
}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

fun evaluate(expression : Expression) : Int = when ( expression ) {
	is Num 	->  expression.value 
	is Sum  ->  evaluate(expression.right) + evaluate(expression.left)
	else 	->  throw IllegalArgumentException("Unknown Arguments...")
}

fun playWithEvaluateFunction() {
	var result : Int 

	// 100 + 200
	result = evaluate( Sum( Num(100), Num(200) ))
	println("Result : $result")
	
	// ( 100 + 200 ) + 500
	result = evaluate( Sum( Sum( Num(100), Num(200) ), Num(500)) ) 
	println("Result : $result")
}

// _____________________________________________________
// Experiment Following Code, Moment Done >>> RAISE HAND!

enum class Color {
	RED, GREEN, BLUE, ORANGE, YELLOW
}

// This Code Color Means RED, GREEN, BLUE, ORANGE, YELLOW
fun getStringForColor(color: Color) : String {
	return when (color) {
		Color.RED 		-> "Red Color"
		Color.GREEN 	-> "Green Color"
		Color.BLUE 		-> "Blue Color"
		Color.ORANGE 	-> "Orange Color" // Better Code Is Without else Branch
		Color.YELLOW	-> "Yellow Color"
		// else 		->  "Unknown Color" 
	}
	// error: 'when' expression must be exhaustive, 
	// add necessary 'ORANGE' branch or 'else' branch instead
}

// This Code Color Means RED, GREEN, BLUE, ORANGE, YELLOW
fun getColorWarmth(color: Color) : String {
	return when (color) {
		Color.RED,  				-> "Warm Color"
		Color.GREEN, Color.BLUE 	-> "Cold Color"
		Color.ORANGE, Color.YELLOW	-> "Neutral Color" 
		// else 		->  "Unknown Color" 
	}
	// error: 'when' expression must be exhaustive, 
	// add necessary 'ORANGE' branch or 'else' branch instead
}

fun playWithColors() {
	println( Color.RED )
	println( Color.GREEN )
	println( Color.BLUE )

	println( getStringForColor(Color.RED) )
	println( getStringForColor(Color.GREEN ) )
	println( getStringForColor(Color.BLUE ) )
}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

sealed class Expr {
	class Num(val value: Int) : Expr()
	class Sum(val left: Expr, val right: Expr) : Expr()
}

fun evaluateAgain(expression : Expr) : Int = when ( expression ) {
	is Expr.Num  ->  expression.value 
	is Expr.Sum  ->  evaluateAgain(expression.right) + evaluateAgain(expression.left)
	// else 		 ->  throw IllegalArgumentException("Unknown Arguments...")
}

fun playWithEvaluateAgainFunction() {
	var result : Int 

	// 100 + 200
	result = evaluateAgain( Expr.Sum( Expr.Num(100), Expr.Num(200) ))
	println("Result : $result")
	
	// ( 100 + 200 ) + 500
	result = evaluateAgain( Expr.Sum( Expr.Sum( Expr.Num(100), Expr.Num(200) ), Expr.Num(500)) ) 
	println("Result : $result")
}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!
class User(val name: String) {
	var address: String = "Unknown"
		set(value: String) {
			// field is Backing Field For Member Property address
			println("Inside Setter Address Before Change : $field")
			field = value
			println("Inside Setter Address After Change : $field")
		}
}

fun playWithUserAddressBackingField() {
	val alice = User("Alice")

	println("Alice Address : ${alice.address}" );
	alice.address = "ITPL, Whitefield, Bangalore"
	println("Alice Address : ${alice.address}" );
}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!
class WordsLengthCounter {
	var counter : Int = 0
		private set // Making Setter Private

	fun addWord(word: String) {
		counter = counter + word.length
	}
}

fun playWithPropertyAccessorVisibility() {
	val lengthCounter = WordsLengthCounter()

	lengthCounter.addWord("Hi")
	println( lengthCounter.counter )
	lengthCounter.addWord("Hello")
	println( lengthCounter.counter )
	// error: cannot assign to 'counter': the setter is private in 'WordsLengthCounter
	// lengthCounter.counter = "Hello World".length()
}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!
//				 Primary Constructor 
data class Grade(val letter: Char, val points: Double, val credits: Double)

//				 Primary Constructor with Explicitly Using constructor Keyword
open class Person constructor(var firstName: String, var lastName: String) {
    fun fullName() = "$firstName $lastName"
}

class Student(
	firstName: String, 
	lastName: String, 
	var grades: MutableList<Grade> = mutableListOf<Grade>()
) : Person(firstName, lastName) {
    
    fun recordGrade(grade: Grade) {
        grades.add(grade)
    }

}

fun playWithPrimaryConstructors() {
    val john = Person(firstName = "Johnny", lastName = "Appleseed")
    val jane = Student(firstName = "Jane", lastName = "Appleseed")

    println( john.fullName() ) // Johnny Appleseed

    val history = Grade(letter = 'B', points = 9.0, credits = 3.0)
    jane.recordGrade(history)

    println( jane.fullName() ) // Jane Appleseed
    println( jane.grades )
}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!
// ______________________________________________________
// ______________________________________________________
// ______________________________________________________
// ______________________________________________________


fun main() {
	println("\nFunction : playWithInterface")
	playWithInterface()

	println("\nFunction : playWithInterfaceClickableAndFocusable")
	playWithInterfaceClickableAndFocusable()

	println("\nFunction : playWithInheritance")
	playWithInheritance()

	println("\nFunction : playWithInheritanceAndExtensionFunctions")
	playWithInheritanceAndExtensionFunctions()

	println("\nFunction : playWithEvalFunction")
	playWithEvalFunction()

	println("\nFunction : playWithMaximunFunction")
	playWithMaximunFunction()

	println("\nFunction : playWithEvalIfFunction")
	playWithEvalIfFunction()

	println("\nFunction : playWithEvalIfAgainFunction")
	playWithEvalIfAgainFunction()

	println("\nFunction : playWithEvalWhenFunction")
	playWithEvalWhenFunction()

	println("\nFunction : playWithEvaluateFunction")
	playWithEvaluateFunction()

	println("\nFunction : playWithEvaluateAgainFunction")
	playWithEvaluateAgainFunction()

	println("\nFunction : playWithUserAddressBackingField")
	playWithUserAddressBackingField()

	println("\nFunction : playWithPropertyAccessorVisibility")
	playWithPropertyAccessorVisibility()

	println("\nFunction : playWithPrimaryConstructors")
	playWithPrimaryConstructors()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")

}
