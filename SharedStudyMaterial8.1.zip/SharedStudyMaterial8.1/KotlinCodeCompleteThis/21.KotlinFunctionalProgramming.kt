

import java.util.*


fun Random.randomStrength(): Int {
    return nextInt(100) + 10
}

fun Random.randomDamage(strength: Int): Int {
    return (strength * 0.1 + nextInt(10)).toInt()
}

fun Random.randomBlock(): Boolean {
    return nextBoolean()
}

class Robot(private val name: String) {

    private var strength: Int = 0

    private var health: Int = 100

    private var random: Random = Random()

    var isAlive: Boolean = true

    init {
        strength = random.randomStrength()
        report("Created (strength $strength)")
    }

    fun report(message: String) {
        println("$name: \t$message")
    }

    private fun damage(damage: Int) {
        val blocked = random.randomBlock()

        if (blocked) {
            report("Blocked attack")
            return
        }

        health -= damage
        report("Damage -$damage, health $health")

        if (health <= 0) {
            isAlive = false
        }
    }

    infix fun attack(robot: Robot) {
        val damage = random.randomDamage(strength)
        robot.damage(damage)
    }
}

object Battlefield {

    inline fun beginBattle(firstRobot: Robot, secondRobot: Robot, onBattleEnded: Robot.() -> Unit) {
        var winner: Robot? = null
        battle(firstRobot, secondRobot)
        winner = if (firstRobot.isAlive) firstRobot else secondRobot
        onBattleEnded(winner)
    }

    tailrec fun battle(firstRobot: Robot, secondRobot: Robot) {
        firstRobot.attack(secondRobot)
        if (secondRobot.isAlive.not()) {
            return
        }
        secondRobot.attack(firstRobot)
        if (firstRobot.isAlive.not()) {
            return
        }
        battle(firstRobot, secondRobot)
    }
}


fun main() {
    val firstRobot = Robot("Experimental Space Navigation Droid")
    val secondRobot = Robot("Extra-Terrestrial Air Safety Droid")

    Battlefield.beginBattle(firstRobot, secondRobot) {
        report("Win!")
    }
}
