/*
kotlinc 06KotlinMoreLambdas.kt -include-runtime -d lambdas.jar
java -jar lambdas.jar
*/

package learnKotlin

// _____________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

data class Person(val name: String, val age: Int)

fun findTheOldest(persons: List<Person>) : Person? {
    var maxAge = 0
    
    var theOldest: Person? = null

    for (person in persons) {
        if (person.age > maxAge) {
            maxAge = person.age
            theOldest = person
        }
    }
   	return theOldest
}

fun playWithFindTheOldestPerson() {
    val people = listOf( Person("Alice", 29), Person("Ganesh", 40), 
    	Person("Bob", 31), Person("Ramesh", 20) )
    
    println ( findTheOldest(people) )

 	val joined = people.joinToString( separator = " : " )
 	println(joined)

    // Transform Lambda Every person Will Map To person.name   
    val names = people.joinToString( separator = " : ", 
    					transform = { person : Person -> person.name } )
    println(names)

    // Transform Lambda Every person Will Map To person.age
    val ages = people.joinToString( separator = " # ", 
    					transform = { person : Person -> person.age.toString() } )
    println(ages)

    // Transform Lambda Every person Will Map To person.age
    val ages2 = people.joinToString( separator = " # ", 
    					transform = { person : Person -> (2 * person.age).toString() } )
    println(ages2)
}


// _____________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________

fun main() {
	println("Function : playWithFindTheOldestPerson")
	playWithFindTheOldestPerson()

	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
}
