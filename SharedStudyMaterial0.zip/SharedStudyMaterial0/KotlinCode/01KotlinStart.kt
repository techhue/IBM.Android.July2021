/*
kotlinc 02KotlinBasics.kt -include-runtime -d basics.jar
java -jar basics.jar
*/

package learnKotlin

// Function which Doesn't Takes Any Aruguments
fun helloWorld() {
	println("Hello World!!!")
}

// _____________________________________________________
// Experiment Folloiwng Code, Moment Done RAISE HAND!

// Function which takes Two Int Aruguments and Return Int
fun max(a: Int, b: Int) : Int {
	return if (a > b) a else b
}

// _____________________________________________________
// Experiment Following Code, Moment Done >>>.RAISE HAND!

fun playWithVariableAndConstants() {
	// val Creates Constant Values
	val number: Int = 100
	val pi: Double = 3.14159

	println(number)
	println(pi)

	// number = 8888
	// println(number)

	// var Creates Variable Values
	var variableNumber: Int = 100
	println(variableNumber)
	variableNumber = 999
	println(variableNumber)

	variableNumber = 1_000_000
	println(variableNumber)
	
	var counter: Int = 1
	counter += 1
	counter += 1
	println(counter)
	
	counter = 10
	counter *= 3
	counter /= 2
	println(counter)	
}

// _____________________________________________________
// Experiment Following Code, Moment Done >>> RAISE HAND!

fun playWithDataTypes() {
	var integerValue: Int = 100
	var decimalValue: Double = 12.5

	println(integerValue)
	println(decimalValue)

	integerValue = decimalValue.toInt() // Truncation After Point 
	println(integerValue)

	val hourlyRate: Double = 20.20
	val hoursWorked: Int = 10
	val totalCost: Double = hourlyRate * hoursWorked 
	println(totalCost)

	// LHS Identifier = RHS Value
	// 1. Compiler Will Inference Type From RHS Value
	// 2. Inferenced Type Will Be Binded With LHS Indentifier
	
	// Compiler Interred Type of 42 Value Is Int
	// Inferred Type Int Will Be Binded With something Identifier
	// Hence something Identifier Type Will Become Int 
	val something = 42 

	// Compiler Interred Type of 3.14159 Value Is Double
	// Inferred Type Double Will Be Binded With somethingAgain Identifier
	// Hence SomethingAgain Identifier Type Will Become Double 
	val somethingAgain = 3.14159
	println(something)
	println(somethingAgain)

	val someValue = 3 // 3 of Type Int, Hence someValue will Be Int Type
	
	val doubleValue = someValue.toDouble()
	println(doubleValue)
}


// _____________________________________________________
// Experiment Following Code, Moment Done >>> RAISE HAND!

fun playWithCharAndStringDataTypes() {
	
	// Char and Kotlin.Char are same and both are Character Data Type
	val upperA: Char = 'A' // Inside Single Quotes is Kotlin Character
	val lowerA: kotlin.Char = 'a'

	println(upperA)
	println(lowerA)

	// Data Type of stringValue Indenfier will be String
	// Following 2 lines of code same
	// Explicit Type Annotation
	val stringValue0: String = "Hello World!!!" // Double "" String Value
	
	// Implicitly Type Is Inferred and Inferred Type Is String
	val stringValue1 = "Hello World!!!" // Inside Double Quotes "" String Value
	println(stringValue0)
	println(stringValue1)

	var message = "Hello, " + "My name is "
	val name = "Alice Carol"
	message += name // String Concatenation
	println(message)

	val exclamationMark: Char = '!'
	message += exclamationMark // Can also Concatinate Char With String
	println(message)

	// Identifier name value is substituted
	// To Access Value of Identifier Inside String Use $
	val interpolatedString = "Hello, my name is $name!!!"
	println(interpolatedString)

	// Following Two Lines Are Same
	val oneThird: Double = 1.0 / 3.0 // Here By Default Type Is Double, Not Float
	val oneThirdAgain = 1.0 / 3.0 // Here By Default Type Is Double, Not Float
	
	// Explicitly Annoating With Float Type
	//  error: type mismatch: inferred type is Double 
	//  	but Float was expected
	// 1.0 and 3.0 Type is Double and Double / Double is Double
	// RHS Value is Double and LHS Indentifier is Float
	// Hence Error...
	// val oneThirdOnceAgain: Float = 1.0 / 3.0 // Error

	val oneThirdOnceAgain: Float = (1.0 / 3.0).toFloat()
	println(oneThird)
	println(oneThirdAgain)
	println(oneThirdOnceAgain)
	
	val oneThirdString = "One third is $oneThird is Double Type"	 
	val oneThirdStringAgain = "One third is ${ 1.0/ 3.0 } is Double Type"	 
	println(oneThirdString)
	println(oneThirdStringAgain)

	val bigString = """
			|You can have a stringValue
			|that contains multiple
			|lines
			|using triple quotes
	"""

	println(bigString)
	println(bigString.trimMargin())
}

// _____________________________________________________
// Experiment Following Code, Moment Done >>> RAISE HAND!

fun playWithTupleDataTypes() {
	// Following Three Lines Of Code Are Same
	// Explicitly Annotating LHS with Type
	val coordinates: Pair<Int, Int> = Pair(2, 3)
	// Type of LHS Is Inferred From RHS Value i.e. Pair<Int, Int>
	val coordinatesInferred = Pair(2, 3)

	// Using Infix Notation
	// Type of LHS Is Inferred From RHS Value i.e. Pair<Int, Int>	
	val coordinatesWithTo = 2 to 3

	val x1 = coordinates.first
	val y1 = coordinates.second
	println(x1)
	println(y1)

	val x2 = coordinatesWithTo.first
	val y2 = coordinatesWithTo.second
	println(x2)
	println(y2)

	// Unpacking or Decluttering 
	val (x3, y3) = coordinates
	println(x3)
	println(y3)
	// val (x3, y3) Line Of Code WIll Be Similar To Following
	// val x3 = coordinates.first
	// val y3 = coordinates.second

	println(coordinatesInferred.first)
	println(coordinatesInferred.second)

	// LHS Type WIll Be Inferrenced From RHS i.e. Pair<Double, Double>
	val coordinatesDoubles = Pair(2.22, 3.30)
	println(coordinatesDoubles.first)
	println(coordinatesDoubles.second)

	// LHS Type WIll Be Inferrenced From RHS i.e. Pair<Double, Int>
	val coordinatesMixed = Pair(2.22, 33)
	println(coordinatesMixed.first)
	println(coordinatesMixed.second)

	// LHS Type WIll Be Inferrenced From RHS i.e. Triple<Int, Int, Int>
	val coordinates3D = Triple(2, 3, 1)
	println(coordinates3D.first)
	println(coordinates3D.second)
	println(coordinates3D.third)

	// Unpacking or Decluttering 
	val (x4, y4, z4) = coordinates3D
	println(x4)
	println(y4)
	println(z4)

	val (x5, y5, _) = coordinates3D
	println(x5)
	println(y5)

	val (x6, _, y6) = coordinates3D
	println(x6)
	println(y6)
}

// _____________________________________________________
// Experiment Following Code, Moment Done >>> RAISE HAND!

fun playWithDataTypesAgain() {
	val a: Short = 12
	val b: Byte = 120
	val c: Int = -100000

	val d = 999 // By Default Type Will Be Int
	println(d)

	// LHS Type Will Be Inferred From RHS Expression/Value
	// Typecast to Upper Type i.e. Short and Byte Will Become Int
	// 		a + b + c result will become Int
	//		Hence LHS answer Type Will Be Int
	val answer = a + b + c 
	println(answer)

	val anyNumber: Any = 42
	val anyString: Any = "Any String Value..."
	val anyDouble: Any = 46.90
}

// _____________________________________________________
// Experiment Following Code, Moment Done >>> RAISE HAND!

// fun playWithKotlinExpressions() {	
//     val yes = true
//     val no = false

//     val doesOneEqualTwo = (1 == 2)
//     val doesOneNotEqualTwo = (1 != 2)
//     val alsoTrue = !(1 == 2)
//     val isOneGreaterThanTwo = (1 > 2)
//     val isOneLessThanTwo = (1 < 2)

//     val and = true && true
//     val or = true || false

//     val andTrue = 1 < 2 && 4 > 3
//     val andFalse = 1 < 2 && 3 > 4

//     val orTrue = 1 < 2 || 3 > 4
//     val orFalse = 1 == 2 || 3 == 4

//     val andOr = (1 < 2 && 3 > 4) || 1 < 4	

//     val guess = "dog"
//     val dogEqualsCat = guess == "cat"

//     val order = "cat" < "dog"
//     println("ORDER = " + order)
// }

// _____________________________________________________
// Experiment Following Code, Moment Done >>> RAISE HAND!

fun playWithIfElseConstructs() {
	// if ( Expression ) 
	// Expression Can Be Any Logical Expression i.e. Resutling Into true/false
    if (2 > 1) {
        println("Yes, 2 is greater than 1.")
    }

    val animal = "Fox"
    if (animal == "Cat" || animal == "Dog") {
        println("Animal is a house pet.")
    } else {
        println("Animal is not a house pet.")
    }

    val a = 5
    val b = 10
    // Terneary Operator
    // if (Expression) Exp1 else Expr2
    // 		If Expression is true Then if-else Expression Value Will Be Expr1
    //		otherwise it will be Expr2
  
    // if-else Construct is Expression In Kotlin
    // Expression Have Always Return Value
    val min = if (a < b) a else b
    val max = if (a > b) a else b
    println(min)
    println(max)

    val hourOfDay = 12
    val timeOfDay = if (hourOfDay < 6) {
        "Early morning"
    } else if (hourOfDay < 12) {
        "Morning"
    } else if (hourOfDay < 17) {
        "Afternoon"
    } else if (hourOfDay < 20) {
        "Evening"
    } else if (hourOfDay < 24) {
        "Late evening"
    } else {
        "INVALID HOUR!"
    }
    println(timeOfDay)


    val name = "Dicken Lucas"

    if (1 > 2 && name == "Dicken Lucas") {
        println("Haaaa Haaaaa")
    } else {
        println("Hoooo Hooooo")    	
    }

    if (1 < 2 || name == "Dicken Lucas") {
        println("Haaaa Haaaaa")
    } else {
        println("Hoooo Hooooo")    	
    }


    // Predict Output...
    var hoursWorked = 45
    var price = 0
    if (hoursWorked > 40) {
    	// hoursOver40 Scope Is if-else Block
        val hoursOver40 = hoursWorked - 40
        price += hoursOver40 * 50
        hoursWorked -= hoursOver40
    }
    price += hoursWorked * 25
    println(price)
    // println(hoursOver40) // error: unresolved reference: hoursOver40
}

// _____________________________________________________


fun playWithLoops() {
	// Predict The Output
    var sum = 1
    while (sum < 1000) {
        sum = sum + (sum + 1)
    }
    println(sum)

    sum = 1
    do {
        sum = sum + (sum + 1)
    } while (sum < 1000)
    println(sum)

    sum = 1
    while (true) {
        sum = sum + (sum + 1)
        if (sum >= 1000) {
            break
        }
    }
    println(sum)
}

// _____________________________________________________

fun playWithForLoop() {
	// .. is Range Operator
    val closedRange = 0..5 // Closed Interval [0, 5] i.e. Both 0 and 5 inclusive
    val halfOpenRange = 0 until 5 // Half Open [0, 5) i.e. 0 inclusive and 5 excluded

    val decreasingRange = 5 downTo 0 // Closed Interval [5, 0]
    for (i in decreasingRange) {
        println(i)
    }

    val count = 10
    var sum = 0
    // i Values : 1, 2, 3, 4,...
    for (i in 1..count) { // Default step is 1
        sum += i
    }
    println(sum)

    sum = 1
    var lastSum = 0
    repeat(10) {
        val temp = sum
        sum += lastSum
        lastSum = temp
    }
    println(sum)

    sum = 0
    // i Values : 1, 3, 5....
    for (i in 1..count step 2) {
        sum += i
    }
    println(sum)

    sum = 0
    for (i in count downTo 1 step 2) {
        sum += i
    }
    println(sum)

	// Following For Loops Are Equivalent
    sum = 0
    for (row in 0 until 8) {
        if (row % 2 == 0) {
            continue
        }

        for (column in 0 until 8) {
            sum += row * column
        }
    }
    println(sum)

    sum = 0
    // Labels
    rowLoop@ for (row in 0 until 8) {
        columnLoop@ for (column in 0 until 8) {
            if (row == column) {
                continue@rowLoop
            }
            sum += row * column
        }
    }
    println(sum)
}


// _____________________________________________________
// Experiment Following Code, Moment Done >>> RAISE HAND!

fun playWithWhenExpression() {
    val number = 10

    // when Expression is Similar to switch in C/C++/Java
    when (number) {
        0 -> println("Zero")
        else -> println("Non-zero") // else part means default block
    }

    when (number) {
        10 -> println("It's ten!")
    }

    when (number) {
        0 -> println("Zero")
        10 -> println("It's ten!")
        else -> println("Non-zero") // else part means default block
    }

    val string = "Dog"
    when (string) {
        "Cat", "Dog" -> println("Animal is a house pet.")
         else -> println("Animal is not a house pet.")
    }

	// when Construct In Kotlin is Expression
	// 	It has return value
    val numberName = when (number) {
        2 -> "two"
        4 -> "four"
        6 -> "six"
        8 -> "eight"
        10 -> "ten"
        else -> {
            println("Unknown number")
            "Unknown"
        }
    }
    println(numberName)


    val hourOfDay = 12
    var timeOfDay: String

	timeOfDay = when (hourOfDay) {
	     0, 1, 2, 3, 4, 5 	-> "Early morning"
	     6, 7, 8, 9, 10, 11 -> "Morning"
	     12, 13, 14, 15, 16 -> "Afternoon"
	     17, 18, 19 		-> "Evening"
	     20, 21, 22, 23 	-> "Late evening"
	     else 				-> "INVALID HOUR!"
	}
    println(timeOfDay)

    timeOfDay = when (hourOfDay) {
        in 0..5 	-> "Early morning"
        in 6..11 	-> "Morning"
        in 12..16 	-> "Afternoon"
        in 17..19 	-> "Evening"
        in 20..23 	-> "Late evening"
        else 		-> "INVALID HOUR!"
    }
    println(timeOfDay)
}


// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________

fun main() {
	println("Function : helloWorld")
	helloWorld()

	println("Function : max")
	println(max(100, 290))
	println(max(-100, 100))

	println("Function : playWithVariableAndConstants")
	playWithVariableAndConstants()
	
	println("Function : playWithDataTypes")
	playWithDataTypes()
	
	println("Function : playWithCharAndStringDataTypes")
	playWithCharAndStringDataTypes()

	println("Function : playWithTupleDataTypes")
	playWithTupleDataTypes()

	println("Function : playWithDataTypesAgain")
	playWithDataTypesAgain()

	// println("Function : playWithKotlinExpressions")
	// playWithKotlinExpressions()

	println("Function : playWithIfElseConstructs")
	playWithIfElseConstructs()

	println("Function : playWithLoops")
	playWithLoops()

	println("Function : playWithForLoop")
	playWithForLoop()

	println("Function : playWithWhenExpression")
	playWithWhenExpression()

	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
}
