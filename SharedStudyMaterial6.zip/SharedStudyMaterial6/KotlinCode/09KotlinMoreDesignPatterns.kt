
/*
kotlinc 09KotlinMoreDesignPatterns.kt -include-runtime -d patterns.jar
java -jar patterns.jar
*/

package learnKotlin

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// Singleton Design Pattern

// Singleton Classes Can Have At The Most One Instance
// class Singleton {
// 	// static variable single_instance of type Singleton
// 	private static Singleton single_instance = null;

// 	// variable of type String
// 	public String s;

// 	// private constructor restricted to this class itself
// 	private Singleton() {
// 		s = "Hello I am a string part of Singleton class";
// 	}

// 	// static method to create instance of Singleton class
// 	public static Singleton getInstance() {
// 		if (single_instance == null)
// 			single_instance = new Singleton();

// 		return single_instance;
// 	}
// }

// Object Classes
// Singleton Design Pattern
// Singleton Classes Can Have At The Most One Instance
// object Classes Are Singleton Classes
// 		Will Define Singleton Named Class
//		Create One Unique Instance of It.
//		You Can Access Unique Instance With Class Name.


object Singleton {
	// variable of type String
	var s: String = "Unknown Value"
}

object X {
	var x = 0
}

fun playWithSingleton() {
	val value: String = Singleton.s 

	println("Value Stored In Singleton Member s : $value")
	println(X.x)

	Singleton.s = "Ding Dong"
	X.x = 9000

	println("Value Stored In Singleton Member s : $value")
	println(X.x)	
}

// _____________________________________________________
// Implement India Singleton Class In Kotlin

// Singleton Class With Unique Object and Object Is Accessed Using Class Name

object India {
	var name : String = "India"

	fun getStates() : List<String> {
		return listOf("Karnatka", "Jammu & Kashmir", "Punjab", "Gujrat", "Tamilnadu",
			"Bihar", "Uttar Pradesh", "Maharastra", "Kerala")		
	}

	fun decoratedName() : String {
		return "Country Name : $name"
	}
}

fun playWithIndia() {
	println(India.name)
	
	India.name = "Bharat"
	println(India.name)

	India.name = "Hindustan!"
	println(India.name)

	println(India.getStates())
	println(India.decoratedName())	
}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// Lazy Object Allocation
// 		i.e. All Objects Are Aloocated In Single Go
//		e.g. email Objects Are Allocated When Person Object Allocated

data class Email(val from: String, val to: String, val subject: String, val body: String) {
	init {
		println("Email Object Getting Created...")
	}
}

fun loadEmails(person: Person) : List<Email> {
	println("Loading Emails For ${person.fullName}")

	val emails = listOf( 
		Email("ding@gmail.com", "dong@gmail.com", "Learn Kotlin", "Kotlin Kotlin Kotlin"),
		Email("ping@gmail.com", "pong@gmail.com", "Learn Java", "Java Java Java Java Java"),
		Email("ting@gmail.com", "tong@gmail.com", "Learn Android", "Android Android Android"),
		Email("zing@gmail.com", "zong@gmail.com", "Android From Google", "Google Google Google"),
	)

	println("Created Email Objects And Returning List Of Emails...")
	return emails
}

class Person(val firstName: String, val lastName: String) {
	init {
		println("Person Object Getting Created...")
	}

	val fullName = "$firstName $lastName"
	val emails = loadEmails(this)
}

fun playWithPersonEmails() {
	val person = Person("Alice", "Carols")
	var emails: List<Email>

	println("\n >>> Acessing Person's Email List...\n")		
	emails = person.emails
	println( emails )

	println("\n >>> Acessing Person's Email List...\n")		
	emails = person.emails
	println( emails )
}

// ______________________________________________________
// Lazy Initialisation Design Pattern

// Lazy Object Allocation
// 		i.e. Objects Aloocated On Demand When Used
//		e.g. email Objects Are Allocated When Emails Are Accessed
//				i.e. First Person Object Is Allocated
//					 Then Email Objects Are Allocated Only When Accessed

fun loadLazyEmails(person: LazyPerson) : List<Email> {
	println("Loading Emails For ${person.fullName}")

	val emails = listOf( 
		Email("ding@gmail.com", "dong@gmail.com", "Learn Kotlin", "Kotlin Kotlin Kotlin"),
		Email("ping@gmail.com", "pong@gmail.com", "Learn Java", "Java Java Java Java Java"),
		Email("ting@gmail.com", "tong@gmail.com", "Learn Android", "Android Android Android"),
		Email("zing@gmail.com", "zong@gmail.com", "Android From Google", "Google Google Google"),
	)

	println("Created Email Objects And Returning List Of Emails...")
	return emails
}

// class Person(val firstName: String, val lastName: String) {
// 	init {
// 		println("Person Object Getting Created...")
// 	}

// 	val fullName = "$firstName $lastName"
// 	val emails = loadEmails(this)
// }

class LazyPerson(val firstName: String, val lastName: String) {
	init {
		println("LazyPerson Object Getting Created...")
	}

	val fullName = "$firstName $lastName"
	private var _emails: List<Email>? = null

	val emails: List<Email>
		get() {
			if ( _emails == null ) {
				// Lazily Loading Emails
				// Lazy Allocation of Emails When emails Property Is Accessed
				_emails = loadLazyEmails(this)
			}
			return _emails!!
		}
}

fun playWithPersonWithLazyEmails() {
	val person = LazyPerson("Alice", "Carols")
	var emails: List<Email>

	println("\n >>> Acessing Person's Email List...\n")		
	emails = person.emails
	println( emails )

	println("\n >>> Acessing Person's Email List...\n")		
	emails = person.emails
	println( emails )
}


// ______________________________________________________

fun loadLazyEmailsAgain(person: LazyPersonAgain) : List<Email> {
	println("Loading Emails For ${person.fullName}")

	val emails = listOf( 
		Email("ding@gmail.com", "dong@gmail.com", "Learn Kotlin", "Kotlin Kotlin Kotlin"),
		Email("ping@gmail.com", "pong@gmail.com", "Learn Java", "Java Java Java Java Java"),
		Email("ting@gmail.com", "tong@gmail.com", "Learn Android", "Android Android Android"),
		Email("zing@gmail.com", "zong@gmail.com", "Android From Google", "Google Google Google"),
	)

	println("Created Email Objects And Returning List Of Emails...")
	return emails
}

class LazyPersonAgain(val firstName: String, val lastName: String) {
	init {
		println("LazyPerson Object Getting Created...")
	}

	val fullName = "$firstName $lastName"
	val emails by lazy { loadLazyEmailsAgain(this) }
	// Compiler Will Generete Follwoing Code For Above Line Of Code 

	// private var _emails: List<Email>? = null
	// val emails: List<Email>
	// 	get() {
	// 		if ( _emails == null ) {
	// 			// Lazily Loading Emails
	// 			// Lazy Allocation of Emails When emails Property Is Accessed
	// 			_emails = loadLazyEmails(this)
	// 		}
	// 		return _emails!!
	// 	}
}

fun playWithPersonWithLazyEmailsAgain() {
	val person = LazyPersonAgain("Alice", "Carols")
	var emails: List<Email>

	println("\n >>> Acessing Person's Email List...\n")		
	emails = person.emails
	println( emails )

	println("\n >>> Acessing Person's Email List...\n")		
	emails = person.emails
	println( emails )
}

// ______________________________________________________
// Design Using Inheritance

open class Spiderman {
	open fun fly() 		=  println( "Fly Like Spiderman!" )
	open fun saveWorld() =  println( "SaveWorld Like Spiderman!" )
}

class Human : Spiderman() {
	override fun fly() 		=  super.fly() 			// println( "Fly..." )
	override fun saveWorld() =  super.saveWorld() 	// println( "SaveWorld..." )
}

fun playWithHuman() {
	val human = Human()
	human.fly()
	human.saveWorld()
}

// ______________________________________________________
// Design Using Composition/Delegation

class NewSpiderman {
	fun fly() 		=  println( "Fly Like Spiderman!" )
	fun saveWorld() =  println( "SaveWorld Like Spiderman!" )
}

class NewHuman {
	val power = NewSpiderman() 				// power Is Acting As Delegate
	fun fly() 		=  power.fly() 			// println( "Fly..." )
	fun saveWorld() =  power.saveWorld() 	// println( "SaveWorld..." )
}

fun playWithNewHuman() {
	val human = NewHuman()
	human.fly()
	human.saveWorld()
}

// ______________________________________________________
// ______________________________________________________
// ______________________________________________________
// ______________________________________________________
// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!


fun main() {

	println("\nFunction : playWithSingleton")
	playWithSingleton()

	println("\nFunction : playWithIndia")
	playWithIndia()
	
	println("\nFunction : playWithPersonEmails")
	playWithPersonEmails()
	
	println("\nFunction : playWithPersonWithLazyEmails")
	playWithPersonWithLazyEmails()
	
	println("\nFunction : playWithPersonWithLazyEmailsAgain")
	playWithPersonWithLazyEmailsAgain()

	println("\nFunction : playWithHuman")
	playWithHuman()

	println("\nFunction : playWithNewHuman")
	playWithNewHuman()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")

}
