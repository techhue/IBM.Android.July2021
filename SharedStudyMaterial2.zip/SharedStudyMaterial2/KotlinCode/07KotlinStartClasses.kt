
/*
kotlinc 07KotlinStartClasses.kt -include-runtime -d classes.jar
java -jar classes.jar
*/

package learnKotlin

// _____________________________________________________
// Experiment Folloiwng Code, Moment Done RAISE HAND!

// Compiler Will Generate Following Things
// 1. Generate Memberwise Constructor Person(firstName, lastName)
// 2. Generate 3 Member Variables To Store Data
//		Corresponding To firstName, lastName, fullName Properties
// 3. Generate Getters and Setters
//		firstName and lastName Properties Both Getters and Setters Will Generated
//	    fullName Property Only Getter is Define

class Person(var firstName: String, var lastName: String) {
	var fullName: String = ""
		get() {  			// Custom Getter Function
			println("fullName Getter Called...")
			return "$firstName $lastName"
		}
		set(value) {  		// Custom Setter Function
			println("fullName Setter Called...")
			field = value
		}
}	

fun playWithPerson() {
	val alice = Person(firstName = "Alice", lastName = "Carols")
	println( alice.firstName )  	// alice.getFirstName()
	println( alice.lastName )   	// alice.getLastName()
	println( alice.fullName )		// alice.getFullName()

	alice.firstName = "Alisa"		// alice.setFirstName("Alisa")
	alice.lastName = "Carolina"		// alice.setLastName("Carolina")
	alice.fullName = "Alisa Carolina" // error: val cannot be reassigned

	println( alice.firstName )
	println( alice.lastName )
	println( alice.fullName )
}

// _____________________________________________________

class SimplePerson(var name: String)

fun playWithObjectEquality() {
	val simplePerson = SimplePerson(name = "John")
	//println(simplePerson.name)

	// Reference/Address/Pointer Assignment
	val simplePersonDuplicate = simplePerson

	//println(simplePersonDuplicate.name)
	simplePersonDuplicate.name = "John Mcmillan"
	
	println(simplePerson.name)
	println(simplePersonDuplicate.name)

	// Function : playWithObjectEquality
	// John Mcmillan
	// John Mcmillan

	val simplePerson1 = SimplePerson(name = "John")

	val simplePerson2 = SimplePerson(name = "Johnny")

	// Reference/Address/Pointer Comparision
	// By Default Comparing References Not Actual Objects
	println( simplePerson == simplePersonDuplicate ) // true
	println( simplePerson == simplePerson1 ) 		 //	false
	println( simplePerson == simplePerson2 ) 		 //	false

	// Following Will Be Comparing References Not Actual Objects
	println( simplePerson === simplePersonDuplicate ) 
	println( simplePerson === simplePerson1 ) 		 
	println( simplePerson === simplePerson2 ) 		 
}

// _____________________________________________________

// class Student(
// 	val firstName: String, 
// 	val lastName: String, 
// 	val grades: MutableList<Grade> = nutableListOf(),
// )

// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________

fun main( ) {
	println("Function : playWithPerson")
	playWithPerson()

	println("Function : playWithObjectEquality")
	playWithObjectEquality()

	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
}
