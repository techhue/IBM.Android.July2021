
DAY 01
____________________________________________________________

	A1.1 Kotlin Code [ MUST ]
		 Practice and Revise Kotlin Code Done Till Nwo

	A1.2 Kotlin Study Notes [ MUST ]
		 KotlinNotes2-6.Shared.pdf


DAY 02
____________________________________________________________
	
	A2.1 Kotlin Code [ MUST ]
		 Practice and Revise Kotlin Code Done Till Nwo

	A2.2 Kotlin Study Notes [ MUST ]
		 KotlinNotes2-6.Shared.pdf
		 KotlinNotes2.Shared.pdf

DAY 03
____________________________________________________________

	A3.0 Previous Pending Reading And Code Practice Assignments

	A3.1 Kotlin Code [ MUST ]
		 Practice and Revise Kotlin Code Done Till Nwo

	A3.2 Kotlin Study Notes [ MUST ]
		 KotlinNotes3.Shared.pdf
		 KotlinNotes4.Shared.pdf


DAY 04
____________________________________________________________

DAY 05
____________________________________________________________

DAY 06
____________________________________________________________

DAY 07
____________________________________________________________

DAY 08
____________________________________________________________

DAY 09
____________________________________________________________

DAY 10
____________________________________________________________


