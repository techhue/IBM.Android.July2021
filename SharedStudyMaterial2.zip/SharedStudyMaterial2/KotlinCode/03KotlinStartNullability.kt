
/*
kotlinc 03KotlinStartNullability.kt -include-runtime -d startnullability.jar
java -jar startnullability.jar
*/

package learnKotlin

// _____________________________________________________
// Experiment Folloiwng Code, Moment Done RAISE HAND!

fun playWithNullabilityAndNonNullability() {
	// String, Int, Float, Double etc... Are NON NULLABLE Types
	//		i.e. You CAN'T Assign null Value To These Types Variables
	var name: String = "Alice Carol"
	var age: Int = 30
	var occupation: String = "Software Engineer"

	println("$name $age $occupation")
	name = "Alice Carol Mcmillan"
	age = 40
	age = age + 1
	occupation = "Sr. Software Engineer"
	println("$name $age $occupation")	

	// name = null  		// error: null can not be a value of a non-null type String
	// age = null 	 		// error: null can not be a value of a non-null type Int
	// occupation = null 	// error: null can not be a value of a non-null type String

	// Nullabe Types Are Also Called Optional Types
	// String?, Int?, Float?, Double? etc... Are NULLABLE Types
	//		i.e. You CAN Assign null Value To These Types Variables
	var name1: String? = "Alice Carol"
	var age1: Int? = 30
	var occupation1: String? = "Software Engineer"

	println("$name1 $age1 $occupation1")
	name1 = "Alice Carol Mcmillan"
	age1 = 40
	age1 = age1 + 1
	occupation1 = "Sr. Software Engineer"
	println("$name1 $age1 $occupation1")	

	name1 = null  		
	age1 = null 	 	
	occupation1 = null 	
	println("$name1 $age1 $occupation1")
}

// _____________________________________________________
// Experiment Folloiwng Code, Moment Done RAISE HAND!

fun playWithNullabilityAndNonNullabilityAgain() {

	var authorName: String? = "Joe Howard"
    var authorAge: Int? = 24

    println(authorName)
    println(authorAge)
    //val ageAfterBirthday = authorAge + 1

    // error: only safe (?.) or 
    // non-null asserted (!!.) calls are allowed on a 
    // nullable receiver of type Int?
    
    // ?. is Safe Calls Operator

    val ageAfterBirthday0 = authorAge?.plus(1)
    println("After their next birthday, author will be $ageAfterBirthday0")

    val ageAfterBirthday1 = authorAge!! + 1    
    println("After their next birthday, author will be $ageAfterBirthday1")

	// authorAge = null
    println("After two birthdays, author will be $authorAge")

	var nonNullableAuthor: String = ""
    var nullableAuthor: String? = ""

    if (authorName != null) {
        nonNullableAuthor = authorName
    } else {
        nullableAuthor = authorName
    }

    println(nonNullableAuthor)
    println(nullableAuthor)
    // var nameLength = authorName.name //  error: unresolved reference: name
 
    // ?. is Safe Calls Operator
    var nameLength = authorName?.length
    println("Author's name has length $nameLength.")

    val nameLengthPlus5 = authorName?.length?.plus(5)
    println("Author's name length plus 5 is $nameLengthPlus5.")
}

// _____________________________________________________
// Experiment Folloiwng Code, Moment Done RAISE HAND!

fun playWithElvisOperator() {
	
	var something: String? = "Good Morning!"
	println(something)
	// something = null
	// println(something)

	// Style 1
	if (something != null ) {
		val upperValue = something.uppercase()
		println("$upperValue")
	} else {
		println("It Contains >>> Null Value...")
	}

	// Style 2
	val upperSomething0 = if (something != null) something.uppercase() else "" 
	
	// Style 3
	// ?: is Called Elvis Operator
	//		Default Values Written After This
	val upperSomething1 = something ?: "" // ?: DEAFULT VALUE
	
	println(upperSomething0)
	println(upperSomething1)

	var nullableValue: Int? = 10
	
	var mustHaveValue0 = if (nullableValue != null) nullableValue else 0
	println(mustHaveValue0)
//	Above Two Lines and Below Two Lines Of Code Are Eqivalent
	var mustHaveValue1  = nullableValue ?: 0
	println(mustHaveValue1)

	nullableValue = null
	mustHaveValue0 = nullableValue ?: 0
	println(mustHaveValue0)
}


// _____________________________________________________
// _____________________________________________________

fun main() {
	println("Function : playWithNullabilityAndNonNullability")
	playWithNullabilityAndNonNullability()

	println("Function : playWithNullabilityAndNonNullabilityAgain")
	playWithNullabilityAndNonNullabilityAgain()

	println("Function : playWithElvisOperator")
	playWithElvisOperator()
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
}
