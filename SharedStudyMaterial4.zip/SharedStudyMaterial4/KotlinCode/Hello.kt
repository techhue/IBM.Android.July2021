
/*
kotlinc Hello.kt -include-runtime -d hello.jar
java -jar hello.jar
*/

package learnKotlin

fun main() {
	println("Hello World!!!")
}



/*

Array Name a
Values	10	20	30	50
Index	0 	1 	2 	3

set(index, value)
set(2, 100)
a[2] = 100

Values	10	20	100	50
Index	0 	1 	2 	3

_________

Array Name a
Values	10	20	30	50
Index	0 	1 	2 	3

insert(index, value)
insert(2, 100)

Values	10	20	| 100	| 30  50
Index	0 	1 	| 2 	|	3 	4

*/

