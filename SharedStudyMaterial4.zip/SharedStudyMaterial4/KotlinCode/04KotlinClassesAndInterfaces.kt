package learnKotlin

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// Interface Tells What To Be Implemented
// What It WIll Do
interface Clickable {
    fun click()
}

// Classes Will Implement The Interfaces
// How, When, Where, Which Way etc.. Will Be Done By Concrete Classes
// e.g. Button is Concrete Class

class Button : Clickable { // Button Class Conforming To Clicable Interfaces
    override fun click() {
    	println("I was clicked")
    }
}

fun playWithInterface() {
    val button = Button()
    button.click()
}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

interface Clickable1 {
    fun click()
    fun showOff() { // Function With Default Implementation
    	println("I'm clickable1!")
    }
}

interface Focusable1 {
    fun setFocus(b: Boolean) { // Function With Default Implementation
        println("I ${if (b) "got" else "lost"} focus.")
    }

    fun showOff() { // Function With Default Implementation
    	println("I'm focusable1!")
    }
}

class Button1 : Clickable1, Focusable1 {
	// error: class 'Button1' is not abstract and 
	// does not implement abstract member public abstract fun click()
    // override fun click() = println("I was clicked")

    override fun click() = println("I was clicked") 

    override fun showOff() {
    	// error: many supertypes available, 
    	// please specify the one you mean in angle brackets, e.g. 'super<Foo>'
    	// super.showOff()
        super<Clickable1>.showOff()
        super<Focusable1>.showOff()
    }
}

fun playWithInterfaceClickableAndFocusable() {
    val button = Button1()
    button.showOff()
    button.setFocus(true)
    button.click()
}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// In Kotlin By Default Classes And Member Functions Are Final
// 		i.e. You CANN'T Override Them In Child Class
//		To Override Functions in Child Class You Should Explciitly Make It Open

// In Java By Default Classes And Member Functions Are Open
// 		i.e. You CAN Override Them In Child Class
//		To NOT TO Override Functions in Child Class You Should Explciitly Make It Final

open class View2 {	// Parent Class
	open fun click() {  println("View2 Got Clicked!") }
	open fun descibeMe() { println("View2 Description...") }
}
// Inheritance : Button2 Inheriting From View2
//		View2 Is Parent Class
//		Button2 Is Child Class
open class Button2 : View2() { // Creating Child Class Button2
	override fun click() { println("Button2 Got Clicked!")	}

	open fun magic() { println("Button2 Doing Magic...") }

	fun disable() = println("Disabling Button2")
}

class RichButton2 : Button2() {
	override fun descibeMe() = println("Very Rich Button... Become Rich!!!")
	override fun magic() 	= println("RichButton1 Doing Magic...")
}

fun playWithInheritance() {
	val view = View2()
	view.click() 
	view.descibeMe()

	val button = Button2()
	button.click()
	button.descibeMe()
	button.magic()
	button.disable()

	val richButton = RichButton2()
	richButton.click()
	richButton.descibeMe()
	richButton.magic()
	richButton.disable()
}


// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!
// ______________________________________________________
// ______________________________________________________
// ______________________________________________________
// ______________________________________________________
// ______________________________________________________
// ______________________________________________________
// ______________________________________________________
// ______________________________________________________


fun main() {
	println("Function : playWithInterface")
	playWithInterface()

	println("Function : playWithInterfaceClickableAndFocusable")
	playWithInterfaceClickableAndFocusable()

	println("Function : playWithInheritance")
	playWithInheritance()

	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
}
