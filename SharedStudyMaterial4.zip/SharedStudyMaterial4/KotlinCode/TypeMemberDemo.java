
class TypeMember {
	public static void doMagic() {
		System.out.println("Class/Type Member Called... Doing Magic");
	}
}

public class TypeMemberDemo {
	public static void playWithCompanionObjects() {
		TypeMember.doMagic();
	}

	public static void main(String[] args) {
		playWithCompanionObjects();
	}
}
