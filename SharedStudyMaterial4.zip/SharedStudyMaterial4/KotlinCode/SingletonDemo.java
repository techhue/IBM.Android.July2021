
import java.util.ArrayList;

// Java program implementing Singleton class
// with getInstance() method

// Singleton Design Pattern

// Singleton Classes Can Have At The Most One Instance
class Singleton {
	// static variable single_instance of type Singleton
	private static Singleton single_instance = null;

	// variable of type String
	public String s;

	// private constructor restricted to this class itself
	private Singleton() {
		s = "Hello I am a string part of Singleton class";
	}

	// static method to create instance of Singleton class
	public static Singleton getInstance() {
		if (single_instance == null)
			single_instance = new Singleton();

		return single_instance;
	}
}


// Static Members
//		Class/Type Member i.e. Accessed Using Class/Type
// Non Static Members
// 		Instance Member i.e. Accessed Using Instance/Object

// Singleton Class
class India {
	// static variable single_instance of type Singleton
	// Class/Type Member i.e. Accessed Using Class/Type
	private static India unique_instance = null;

	// Class/Type Member i.e. Accessed Using Class/Type
	public static String name = "Unknown";  
	
	// Instance Member i.e. Accessed Using Instance/Object
	public String type = "Nation"; 

	// private constructor restricted to this class itself
	private India() {
		name = "India";
	}

	// Class/Type Member i.e. Accessed Using Class/Type
	// static method to create instance of Singleton class
	public static India getInstance() {
		if (unique_instance == null)
			unique_instance = new India();

		return unique_instance;
	}

	// Class/Type Member i.e. Accessed Using Class/Type
	public static String getDecoratedName() { 
		return "Country Name : " + name;
	}

	// Instance Member i.e. Accessed Using Instance/Object
	public ArrayList<String> getStates() {
		ArrayList<String> states = new ArrayList<String>();

		states.add( "Karnatka" );
		states.add( "Jammu & Kashmir");
		states.add( "Punjab") ; 
		states.add( "Gujrat" );
		states.add( "Tamilnadu");
		states.add( "Bihar");
		states.add( "Uttar Pradesh") ; 
		states.add( "Maharastra") ; 
		states.add( "Kerala" );

		return states;		
	}
}


public class SingletonDemo {

	public static void playWithIndia() {		
		India india = India.getInstance();
		India bharat = India.getInstance();

		// Class/Type Member i.e. Accessed Using Class/Type
		System.out.println("String from India is " + India.name);
		India.name = "India";
		System.out.println("String from India is " + India.name);


		// Instance Member i.e. Accessed Using Instance/Object
		System.out.println("Type  :  " + india.type);
		india.type = "Big Nation";
		System.out.println("Type  :  " + india.type);
		

		// Class/Type Member i.e. Accessed Using Class/Type
		System.out.println("String from India is " + India.name);		
		India.name = "Bharat";
		System.out.println("String from India is " + India.name);
		
		// Instance Member i.e. Accessed Using Instance/Object
		System.out.println("Type  :  " + bharat.type);
		bharat.type = "Ancient Nation";
		System.out.println("Type  :  " + bharat.type);

		// Instance Member i.e. Accessed Using Instance/Object
		System.out.println( india.getStates() );
		System.out.println( bharat.getStates() );

		// Class/Type Member i.e. Accessed Using Class/Type
		System.out.println( India.getDecoratedName() );
		System.out.println( India.getDecoratedName() );

	}

	public static void playWithSingleton() {
		// instantiating Singleton class with variable x
		
		// error: Singleton() has private access in Singleton
		// Singleton xx = new Singleton();
		
		Singleton x = Singleton.getInstance();

		// instantiating Singleton class with variable y
		Singleton y = Singleton.getInstance();

		// instantiating Singleton class with variable z
		Singleton z = Singleton.getInstance();

		// changing variable of instance x
		x.s = (x.s).toUpperCase();

		System.out.println("String from x is " + x.s);
		System.out.println("String from y is " + y.s);
		System.out.println("String from z is " + z.s);
		System.out.println("\n");

		// changing variable of instance z
		z.s = (z.s).toLowerCase();

		System.out.println("String from x is " + x.s);
		System.out.println("String from y is " + y.s);
		System.out.println("String from z is " + z.s);
	}


	public static void main(String args[]) {
		System.out.println("\nFunction : playWithSingleton");
		playWithSingleton();

		System.out.println("\nFunction : playWithIndia");
		playWithIndia();
	
		// System.out.println("\nFunction : ")
		// System.out.println("\nFunction : ")
		// System.out.println("\nFunction : ")
		// System.out.println("\nFunction : ")
		// System.out.println("\nFunction : ")
		// System.out.println("\nFunction : ")
		// System.out.println("\nFunction : ")
	}
}

