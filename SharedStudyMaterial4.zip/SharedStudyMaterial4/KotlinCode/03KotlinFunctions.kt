/*
kotlinc 03KotlinFunctions.kt -include-runtime -d functions.jar
java -jar functions.jar
*/

package learnKotlin;

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

class Human(val firstName: String, val lastName: String) {
	// Instance Member Property
	val fullName = "$firstName $lastName"
	// Instance Member Function
	fun doMagic() = println("Human Doing Magic...")
	// Instance Member Function
	// fun doSomething() {
	// 	println("Doing Something...")
	// }
}

// doSomething is Exteions Function On Type Human
//		Accessed Like A Instance Member Function
fun Human.doSomething() {
	println("doSomething Extension Function On Human Class/Type Called...")
}

// Exteions Function On Type Human
fun Human.doDance() {
	println("doDance Extension Function On Human Class/Type Called...")
}

fun playWithHuman() {
	val human = Human("Alice", "Carol")
	println(human.firstName)
	println(human.lastName)
	println(human.fullName)

	human.doMagic()
	//doSomething()
	human.doSomething()
	human.doDance()
}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

fun main() {
	println("\nFunction : playWithHuman")
	playWithHuman()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}
