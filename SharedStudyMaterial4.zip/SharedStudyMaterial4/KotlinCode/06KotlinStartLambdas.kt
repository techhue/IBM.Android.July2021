
/*
kotlinc 06KotlinStartLambdas.kt -include-runtime -d startlambdas.jar
java -jar startlambdas.jar
*/

package learnKotlin

// _____________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// addition Function Has Type
// Function Type (Int, Int) -> Int
fun addition(a: Int, b: Int) : Int {
	return a + b
}

// addition Function Has Type
// Function Type (Int, Int, Int) -> Int
fun addition3(a: Int, b: Int, c: Int) : Int {
	return a + b + c
}

// substraction Function Has Type
// Function Type (Int, Int) -> Int
fun substraction(a: Int, b: Int) : Int {
	return a - b
}

// substraction Function Has Type
// Function Type (Int, Int) -> Int
fun multiplication(a: Int, b: Int) : Int {
	return a * b
}

// Passing A Function To A Function As Argument
// Calculator Is Function
// Which Takes One Function As Argument
// (Int, Int, (Int, Int) -> Int ) -> Int
fun calcualator(x: Int, y: Int, operation: (Int, Int) -> Int ) : Int {
	val result = operation(x, y)
	return result
}

fun playWithCalculator() {
	val xx: Int = 100
	val yy: Int = 200
	var result: Int

	result = calcualator(xx, yy, ::addition)
	println("Result : $result")	

	result = calcualator(xx, yy, ::substraction)
	println("Result : $result")	

	result = calcualator(xx, yy, ::multiplication)
	println("Result : $result")	

	// error: type mismatch: inferred type is KFunction3<Int, Int, Int, Int> 
	// but (Int, Int) -> Int was expected

	// result = calcualator(xx, yy, ::addition3)
	// println("Result : $result")	
}

// _____________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// Return Type Will Inferenced From RHS
//	a and b Both Are Int Type and a + b Will Be Int
//	Hence RHS Type Will Be Int, 
//		It Implies That Function addition1 Return Type Will Be Int
fun addition1(a: Int, b: Int) = a + b

// Explicitly Mentioned Return Type
fun substraction1(a: Int, b: Int) : Int = a - b
fun multiplication1(a: Int, b: Int) = a * b 

fun playWithCalculatorAgain() {
	val xx: Int = 100
	val yy: Int = 200
	var result: Int

	result = calcualator(xx, yy, ::addition1)
	println("Result : $result")	

	result = calcualator(xx, yy, ::substraction1)
	println("Result : $result")	

	result = calcualator(xx, yy, ::multiplication1)
	println("Result : $result")	
}

// _____________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

fun playWithCalculatorOnceAgain() {
	val xx: Int = 100
	val yy: Int = 200
	var result: Int
	
	//fun addition1(a: Int, b: Int) = a + b
	// Lambda Expression		// Arguments Followed By(->) Is Body
	val additionLambda : (Int, Int) -> Int 		 = { a: Int, b: Int ->  a + b }
	val substractionLambda : (Int, Int) -> Int	 = { a: Int, b: Int ->  a - b }
	
	// Inferred Type Will Be (Int, Int) -> Int
	val multiplicationLambda = { a: Int, b: Int ->  a * b }

	result = calcualator(xx, yy, additionLambda)
	println("Result : $result")	

	result = calcualator(xx, yy, substractionLambda)
	println("Result : $result")	

	result = calcualator(xx, yy, multiplicationLambda)
	println("Result : $result")	
}

// _____________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

fun playWithLambdas() {
    var multiplyLambda: (Int, Int) -> Int
    var lambdaResult: Int

    multiplyLambda = { a: Int, b: Int -> Int
        a * b
    }

    lambdaResult = multiplyLambda(4, 2) // 8
    println(lambdaResult)

    multiplyLambda = { a, b ->
        a * b
    }

	lambdaResult = multiplyLambda(4, 2) // 8
    println(lambdaResult)
    
    var doubleLambda = { a: Int -> 2 * a }

	lambdaResult = doubleLambda(4) 
    println(lambdaResult)

    doubleLambda = { 2 * it }
	lambdaResult = doubleLambda(4) // 8
    println(lambdaResult)
    
    val square: (Int) -> Int = { it * it }
	lambdaResult = square(4) // 8
    println(lambdaResult)
}

// _____________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

fun playWithLambdasAgain() {
    var resultReturned : Int 

    fun operateOnNumbers(a: Int, b: Int, operation: (Int, Int) -> Int ): Int {
        val result = operation(a, b) // Invoking Lambda And Passing Parameters
        return result
    }

    // Defining A Lamba Expression
    //(Int, Int) -> Int
    val addLambda = { a: Int, b: Int -> a + b }
    resultReturned = operateOnNumbers(4, 2, operation = addLambda)
    println(resultReturned)

    fun addFunction(a: Int, b: Int) = a + b

    resultReturned = operateOnNumbers(4, 2, operation = ::addFunction)
    println(resultReturned)

    resultReturned = operateOnNumbers( 4, 2,
        operation = { a: Int, b: Int ->
            a + b
        }
    )
    println(resultReturned)

    resultReturned = operateOnNumbers( 4, 2, { a, b -> a + b } )
    println(resultReturned)

    resultReturned = operateOnNumbers( 4, 2,
        operation = { a: Int, b: Int ->
            a * b
        }
    )
    println(resultReturned)

    resultReturned = operateOnNumbers(4, 2, operation = Int::plus)
    println(resultReturned)

    // Following Lambdas Definitions Are Equivalent
    resultReturned = operateOnNumbers( 4, 2, { a, b -> a + b } ) 
    println(resultReturned)
    // Trailing Lambda
    // Lambda Is Last Argument Than It Can Be Written Outide of Paranthesis ()
    
    resultReturned = operateOnNumbers(4, 2) { a, b -> a + b }
    println(resultReturned)
    
    resultReturned = operateOnNumbers(4, 2) { 
    	a, b -> a + b 
    }
    println(resultReturned)
}

// _____________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

fun playWithLambdasReturningUnitOrNothing() {
	var unitLambda: () -> Unit = { println("Kotlin Is Awesome!") }
	unitLambda()
	
	unitLambda = { println("Life is Great!!!!package") }
	unitLambda()

//	var nothingLambda: () -> Nothing = { throw NullPointerException() }
//	nothingLambda()
}

// _____________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// Function Scope Start With Curly { Brace And Ends With Curly } Brace
// Lambda Scope Start With Curly { Brace And Ends With Curly } Brace

fun playWithLambdasCapturingContext() { // Enclosing Context i.e. Function Scope
	var counter = 0

	// Enclosed Context Can Capture Variables/Values From Enclosing Context
	var incrementCounter = { // Enlosed Context i.e. Lambda Scope
		counter = counter + 1 
	}

	println(counter)

	incrementCounter() // Invoking Lamdba
	incrementCounter()
	incrementCounter()
	incrementCounter()
	incrementCounter()

	println(counter)
}

// _____________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// Returning Function From Function
// chooseStep Function Returns A Function of Type () -> Int
fun chooseStep(isForward: Boolean) : () -> Int {
	var counter = 0
	// Type of moveForward Function Is () -> Int
	fun moveForward(): Int {
		counter = counter + 1
		return counter
	}
	// Type of moveBackward Function Is () -> Int
	fun moveBackward(): Int {
		counter = counter - 1
		return counter
	}

	if (isForward) return ::moveForward 
	else return ::moveBackward
}

fun playWithChoices() {
	// What Is The Type Of changeValue
	var changeValue: () -> Int = chooseStep(true)
	
	println( changeValue() )
	println( changeValue() )
	println( changeValue() )
	println( changeValue() )
	println( changeValue() )

	changeValue = chooseStep(false)
	
	println( changeValue() )
	println( changeValue() )
	println( changeValue() )
	println( changeValue() )
	println( changeValue() )
}

// _____________________________________________________
// _____________________________________________________
// _____________________________________________________

fun main() {
	println("Function : playWithCalculator")
	playWithCalculator()

	println("Function : playWithCalculatorAgain")
	playWithCalculatorAgain()

	println("Function : playWithCalculatorOnceAgain")
	playWithCalculatorOnceAgain()

	println("Function : playWithLambdas")
	playWithLambdas()

	println("Function : playWithLambdasAgain")
	playWithLambdasAgain()

	println("Function : playWithLambdasReturningUnitOrNothing")
	playWithLambdasReturningUnitOrNothing()

	println("Function : playWithLambdasCapturingContext")
	playWithLambdasCapturingContext()

	println("Function : playWithChoices")
	playWithChoices()
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
}
