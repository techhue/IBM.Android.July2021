
/****  Compling and Running Kotlin Code
kotlinc 15.KotlinAdvancedClasses.kt -include-runtime -d advancedClasses.jar
java -jar advancedClasses.jar
****/

package learnKotlin

// Introducing inheritance
data class Grade(val letter: Char, val points: Double, val credits: Double)

open class Person constructor(var firstName: String, var lastName: String) {
    fun fullName() = "$firstName $lastName"
}

// class Student(
//     var firstName: String, 
//     var lastName: String, 
//     var grades: MutableList<Grade> = mutableListOf<Grade>()
// ) {
//     fun recordGrade(grade: Grade) {
//       grades.add(grade)
//     }
// }

open class Student(
    firstName: String, 
    lastName: String, 
    var grades: MutableList<Grade> = mutableListOf<Grade>()
) : Person(firstName, lastName) {
    open fun recordGrade(grade: Grade) {
        grades.add(grade)
    }
}

fun playWithClassesAndObjects() {
    val john = Person(firstName = "Johnny", lastName = "Appleseed")
    val jane = Student(firstName = "Jane", lastName = "Appleseed")

    john.fullName() // Johnny Appleseed
    jane.fullName() // Jane Appleseed

    val history = Grade(letter = 'B', points = 9.0, credits = 3.0)
    jane.recordGrade(history)
}


open class BandMember(firstName: String, lastName: String) : Student(firstName, lastName) {
    open val minimumPracticeTime: Int
        get() { return 2 }
}

class OboePlayer(firstName: String, lastName: String) : BandMember(firstName, lastName) {
    override val minimumPracticeTime: Int = super.minimumPracticeTime * 2
}

fun phonebookName(person: Person): String {
    return "${person.lastName}, ${person.firstName}"
}

fun playWithPhoneBookName() {
    val person = Person(firstName = "Johnny", lastName = "Appleseed")
    val oboePlayer = OboePlayer(firstName = "Jane", lastName = "Appleseed")

    phonebookName(person) // Appleseed, Johnny
    phonebookName(oboePlayer) // Appleseed, Jane
}

fun playWithRuntimeTypeCheck() {
    // Runtime hierarchy checks
    val oboePlayer = OboePlayer(firstName = "Jane", lastName = "Appleseed")
    var hallMonitor = Student(firstName = "Jill", lastName = "Bananapeel")

    hallMonitor = oboePlayer

    println(hallMonitor is OboePlayer) // true, since assigned it to oboePlayer
    println(hallMonitor !is OboePlayer) // also have !is for "not-is"
    println(hallMonitor is Person) // true, because Person is ancestor of OboePlayer

    // (oboePlayer as Student).minimumPracticeTime // Error: No longer a band member!

    println((hallMonitor as? BandMember)?.minimumPracticeTime) // > 4
}

// Polymorphism
fun afterClassActivity(student: Student): String {
    return "Goes home!"
}

fun afterClassActivity(student: BandMember): String {
    return "Goes to practice!"
}

fun playWithAfterClassActivityFunction() {
    val oboePlayer = OboePlayer(firstName = "Jane", lastName = "Appleseed")

    println(afterClassActivity(oboePlayer)) // Goes to practice!
    println(afterClassActivity(oboePlayer as Student)) // Goes home!
}

// Inheritance, methods, and overrides
class StudentAthlete(
    firstName: String, 
    lastName: String
) : Student(firstName, lastName) {

    val failedClasses = mutableListOf<Grade>()
    override fun recordGrade(grade: Grade) {
        super.recordGrade(grade)

        if (grade.letter == 'F') {
            failedClasses.add(grade)
        }
    }

    val isEligible: Boolean
        get() = failedClasses.size < 3
}

fun playWithStudentAthlete() {
    val math = Grade(letter = 'B', points = 9.0, credits = 3.0)
    val science = Grade(letter = 'F', points = 9.0, credits = 3.0)
    val physics = Grade(letter = 'F', points = 9.0, credits = 3.0)
    val chemistry = Grade(letter = 'F', points = 9.0, credits = 3.0)

    val dom = StudentAthlete(firstName = "Dom", lastName = "Grady")
    dom.recordGrade(math)
    dom.recordGrade(science)
    dom.recordGrade(physics)
    println("${dom.fullName()} is ${if (dom.isEligible) "eligible" else "ineligible"}") // eligible
    dom.recordGrade(chemistry)
    println("${dom.fullName()} is ${if (dom.isEligible) "eligible" else "ineligible"}") // ineligible
}
 
// Introducing super
// When to call super

class StudentAthlete2(firstName: String, lastName: String) : Student(firstName, lastName) {
    var failedClasses = mutableListOf<Grade>()

    override fun recordGrade(grade: Grade) {
        var newFailedClasses = mutableListOf<Grade>()
        for (grade in grades) {
            if (grade.letter == 'F') {
                newFailedClasses.add(grade)
            }
        }
        failedClasses = newFailedClasses

        super.recordGrade(grade)
    }

    val isEligible: Boolean
        get() = failedClasses.size < 3
}

// Allowing inheritance
class FinalStudent(
    firstName: String, 
    lastName: String
) : Person(firstName, lastName)

// class FinalStudentAthlete(
//     firstName: String, 
//     lastName: String
// ): FinalStudent(firstName, lastName) // Build error!

open class AnotherStudent(
    firstName: String, 
    lastName: String
) : Person(firstName, lastName) {
    open fun recordGrade(grade: Grade) {}
    fun recordTardy() {}
}

class AnotherStudentAthlete(
    firstName: String, 
    lastName: String
) : AnotherStudent(firstName, lastName) {
    override fun recordGrade(grade: Grade) {} // OK
//    override fun recordTardy() {} // Build error!
}

// Abstract classes

abstract class Mammal(val birthDate: String) {
    abstract fun consumeFood()
}

class Human(birthDate: String) : Mammal(birthDate) {
    override fun consumeFood() {
        // ...
    }
    
    fun createBirthCertificate() {
        // ...
    }
}

fun playWithHumanAndMammal() {
    val human = Human("1/1/2000")

    // Error: Cannot create an instance of an abstract class
//  val mammal = Mammal("1/1/2000") 
}

sealed class Geometry {
    class Circle(val radius: Int) : Geometry()
    class Square(val sideLength: Int) : Geometry()
}

// Working With Sealed classes
fun sizeOfGeometery(geometry: Geometry): Int {
    return when (geometry) {
        is Geometry.Circle -> geometry.radius
        is Geometry.Square -> geometry.sideLength
    }
}


fun playWithGeometries() {
    val circle1 = Geometry.Circle(4)
    val circle2 = Geometry.Circle(2)
    val square1 = Geometry.Square(4)
    val square2 = Geometry.Square(2)
}

// Secondary Constructors
open class Shape {
    // Secondary Constructors
    constructor(size: Int) {
        // ...
    }
    // Secondary Constructors
    constructor(size: Int, color: String) : this(size) {
        // ...
    }
}

class Circle : Shape {
    // Secondary Constructors
    constructor(size: Int) : super(size) {
        // ...
    }

    // Secondary Constructors
    constructor(size: Int, color: String) : super(size, color) {
        // ...
    }
}

// Nested Class
// CANNOT Assess Outer Class Context, Inside Inner Class
class Car1(val carName: String) {
     class Engine(val engineName: String) {
        override fun toString(): String {
            // Error cannot see outer scope, Hence Cann't Access carName
            //return "$engineName in a $carName" 
            return "$engineName"
        }
    }
}

// Inner Class
//  Can Assess Outer Class Context, Inside Inner Class
class Car2(val carName: String) { // Outer Class
    inner class Engine(val engineName: String) { // Inner Class
        override fun toString(): String {
            return "$engineName engine in a $carName"
        }
    }
}   

// Nested and inner classes
fun playWithNestedAndInnerClasses() {
    val mazda1 = Car1("mazda")
    val mazdaEngine1 = Car1.Engine("rotary")
    println(mazdaEngine1) // > rotary engine in a mazda

    val mazda = Car2("mazda")
    val mazdaEngine = mazda.Engine("rotary")
    println(mazdaEngine) // > rotary engine in a mazda
}

// Visibility modifiers

data class Privilege(val id: Int, val name: String)

open class User(val username: String, private val id: String, protected var age: Int)

class PrivilegedUser(username: String, id: String, age: Int) : User(username, id, age) {
    private val privileges = mutableListOf<Privilege>()

    fun addPrivilege(privilege: Privilege) {
        privileges.add(privilege)
    }

    fun hasPrivilege(id: Int): Boolean {
        return privileges.map { it.id }.contains(id)
    }

    fun about(): String {
        // return "$username, $id" // Error: id is private
        return "$username, $age" // OK: age is protected
    }
}

fun playWithVisibilityModifiers() {
    val privilegedUser = PrivilegedUser(username = "sashinka", id = "1234", age = 21)
    val privilege = Privilege(1, "invisibility")
    privilegedUser.addPrivilege(privilege)
    println(privilegedUser.about()) // sashinka, 21
}

// When and why to subclass
// Single responsibility
// Strong types
data class Sport(val name: String)

class Student2(firstName: String, lastName: String) : Person(firstName, lastName) {
    var grades = mutableListOf<Grade>()
    var sports = mutableListOf<Sport>()
}

class Team {
    var players = mutableListOf<StudentAthlete>()

    val isEligible: Boolean
        get() {
            for (player in players) {
                if (!player.isEligible) {
                    return false
                }
            }
            return true
        }
}

// Shared base classes
open class Button {
    fun press() {
    }
}

class Image
class ImageButton(val image: Image) : Button()
class TextButton(val text: String) : Button()

fun main() {
    println("Function : ")
    playWithClassesAndObjects()
}

