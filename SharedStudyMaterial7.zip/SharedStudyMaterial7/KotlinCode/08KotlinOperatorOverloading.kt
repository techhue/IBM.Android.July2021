/*
kotlinc 08KotlinMoreOperatorOverloading.kt -include-runtime -d operatoroverloading.jar
java -jar operatoroverloading.jar
*/
