
DAY 01
____________________________________________________________

	A1.1 Kotlin Code [ MUST ]
		 Practice and Revise Kotlin Code Done Till Nwo

	A1.2 Kotlin Study Notes [ MUST ]
		 KotlinNotes2-6.Shared.pdf


DAY 02
____________________________________________________________
	
	A2.1 Kotlin Code [ MUST ]
		 Practice and Revise Kotlin Code Done Till Nwo

	A2.2 Kotlin Study Notes [ MUST ]
		 KotlinNotes2-6.Shared.pdf
		 KotlinNotes2.Shared.pdf

DAY 03
____________________________________________________________

	A3.0 Previous Pending Reading And Code Practice Assignments

	A3.1 Kotlin Study Notes [ MUST ]
		 KotlinNotes3.Shared.pdf
		 KotlinNotes4.Shared.pdf

	A3.2 Kotlin Code [ MUST ]
		 Practice and Revise Kotlin Code Done Till Nwo

DAY 04
____________________________________________________________

	A4.0 REVISE ALL KOTLIN NOTES AND CODE PRACTICE [MUST]
		 KotlinNotes2-6.Shared.pdf
		 KotlinNotes2.Shared.pdf
		 KotlinNotes3.Shared.pdf
		 KotlinNotes4.Shared.pdf	

	A4.1 Kotlin Study Notes [ MUST ]
		 KotlinNotes5.Shared.pdf
		 KotlinNotes6.Shared.pdf

	A4.2 Kotlin Code [ MUST ]
		 Practice and Revise Kotlin Code Done Till Now

	A4.3 Read And Practice C Code [MUST ]
	 		Chapter 4 : Functions And Program Structure
	 		Chapter 5 : Pointers And Arrays
	 			The C Programming Langugage, 2nd Edition, By Dennish Ritchie

	A4.4 Reading And Understanding Assignments [ GODD TO HAVE ]
		 Chapter 09: Tables And Information Retrieval
		 		Data Structure And Program Design, By Robert L. Kruse
		 
DAY 05
____________________________________________________________

	A5.1 Kotlin Study Notes [ MUST ]
		 KotlinNotes7.Shared.pdf
		 KotlinNotes8.Shared.pdf
		 KotlinNotes9.Shared.pdf

	A5.2 Kotlin Code [ MUST ]
		 Practice and Revise Kotlin Code Done Till Now

	A5.3 Read And Practice C Code [MUST ]
 		Chapter 5 : Pointers And Arrays
 			The C Programming Langugage, 2nd Edition, By Dennish Ritchie

	A5.4 Reading And Understanding Assignments [ GODD TO HAVE ]
		 Chapter 09: Tables And Information Retrieval
		 		Data Structure And Program Design, By Robert L. Kruse

DAY 06
____________________________________________________________

	A6.1 Kotlin Study Notes [ MUST ]
		 KotlinNotes10.Shared.pdf
		 KotlinNotes11.Shared.pdf

	A6.2 Kotlin Code [ MUST ]
		 Practice And Revise Kotlin Code Done Till Now

	A6.3 Kotlin Programming Assignments [ MUST ]
		Q1. Implement Binary Search Algorithm In Kotlin Language
		Q2. Implement Insertion Sort Algorithm In Kotlin
		Q3. Simulate Following Things In Kotlin Using Classes/Functions/Enums etc...
			 Student Register For Courses
			 Teaches Teaches Courses

	A6.4 Read And Practice C Code [MUST ]
 		Chapter 5 : Pointers And Arrays
 			The C Programming Langugage, 2nd Edition, By Dennish Ritchie


DAY 07
____________________________________________________________

	A7.1 Kotlin Study Notes [ MUST ]
		 KotlinNotes13.Shared.pdf
		 KotlinNotes14.Shared.pdf

	A7.2 Kotlin Code [ MUST ]
		 Practice And Revise Kotlin Code Done Till Now

	A7.3 Kotlin Programming Assignments [ MUST ]
		Q3. Simulate Following Things In Kotlin Using Classes/Functions/Enums etc...
			 Student Register For Courses
			 Teacher Teaches Courses
			 Institute Runs Programs
			 Programs Have Courses

DAY 08
____________________________________________________________

	A8.1 Kotlin Study Notes [ MUST ]
		REVISE EVERYTHING

	A8.2 Kotlin Code [ MUST ]
		 Practice And Revise Kotlin Code Done Till Now
		 COMPLETE CODE EXAMPLES WHICH ARE PARTICIALS
		15.KotlinAdvancedClasses.kt
		20.KotlinExceptions.kt
		21.KotlinFunctionalProgramming.kt

	A8.3 Kotlin Programming Assignments [ MUST ]
		Q3. Simulate Following Things In Kotlin Using Classes/Functions/Enums etc...
			 Student Register For Courses
			 Teacher Teaches Courses
			 Institute Runs Programs
			 Programs Have Courses

DAY 09
____________________________________________________________

	A9.0 RESVISE KOTLIN STUDY NOTES AND CODE EXAMPLES [ MUST ]
		REVISE ALL KOTLIN NOTES AND CODE EXAMPLESEVERYTHING

	A9.1 Study Kotlin Notes [ MUST ]
	    KotlinNotes12.Shared.pdf

	A9.2 Kotlin Code [ MUST ]
		 Practice And Revise Kotlin Code Done EARLIER ALSO
		 COMPLETE ALL CODE EXAMPLES WHICH ARE INCOMPLETE
		
		15.KotlinAdvancedClasses.kt
		10KotlinMoreDownloader.kt
		16.DowloaderCombined.kt		
		20.KotlinExceptions.kt
		21.KotlinFunctionalProgramming.kt

|   |-- 18.KotlinGenerics.kt
|   `-- 22.KotlinOperatorOverloading.kt

	A9.3 Kotlin Programming Assignments [ MUST ]
		Q3. Simulate Following Things In Kotlin Using Classes/Functions/Enums etc...
			 Student Register For Courses
			 Teacher Teaches Courses
			 Institute Runs Programs
			 Programs Have Courses

	A9.4 Android Presenttations [ MUST ]
		01.0 Introduction to Android.pdf
		01.1 Your first Android app.pdf

	A9.5 Android Reading Assignments [ MUST ]
		https://developer.android.com/guide/platform

	A9.6 Android Code Practice [ MUST ]
		EmpptyActivity


DAY 10
____________________________________________________________



DAY 11
____________________________________________________________


DAY 12
____________________________________________________________


DAY 13
____________________________________________________________


DAY 14
____________________________________________________________


DAY 15
____________________________________________________________


DAY 16
____________________________________________________________



DAY 17
____________________________________________________________



DAY 18
____________________________________________________________


