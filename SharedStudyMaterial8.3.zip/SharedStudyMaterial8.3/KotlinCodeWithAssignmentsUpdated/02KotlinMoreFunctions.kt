/*
kotlinc 03KotlinMoreFunctions.kt -include-runtime -d functions.jar
java -jar functions.jar
*/

package learnKotlin;

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!


// Kotlin Collections Are Actually Java Collections Internally

fun playingWithCollectionsInKotlin() {

	val set = hashSetOf(1, 7, 53) 
	val arraylist = arrayListOf(1, 7, 53) 
	val map = hashMapOf(1 to "one", 7 to "seven", 53 to "fifty-three")
    val list = listOf(1, 2, 3)

    println(set.javaClass)  		// class java.util.HashSet
    println(arraylist.javaClass) 	// class java.util.ArrayList
    println(map.javaClass)			// class java.util.HashMap
    println(list.javaClass)			// class java.util.Arrays$ArrayList

    println(set)
    println(list)
    println(map)
    println(list)

    val strings = listOf("first", "second", "fourteenth")
    println(strings.last())
    val numbers = setOf(1, 14, 2)
    println(numbers.maxOrNull())
}


// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

class Human(val firstName: String, val lastName: String) {
	// Instance Member Property
	val fullName = "$firstName $lastName"
	// Instance Member Function
	fun doMagic() = println("Human Doing Magic...")
	// Instance Member Function
	// fun doSomething() {
	// 	println("Doing Something...")
	// }
}

// doSomething is Exteions Function On Type Human
//		Accessed Like A Instance Member Function
fun Human.doSomething() {
	println("doSomething Extension Function On Human Class/Type Called...")
}

// Exteions Function On Type Human
fun Human.doDance() {
	println("doDance Extension Function On Human Class/Type Called...")
}

fun playWithHuman() {
	val human = Human("Alice", "Carol")
	println(human.firstName)
	println(human.lastName)
	println(human.fullName)

	human.doMagic()
	//doSomething()
	human.doSomething()
	human.doDance()
}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// Generics
// T is Type Placeholder or Generic Type
//		i.e. T will Be Replaced With Type
fun <T> jointToString(
	collection: Collection<T>,
	separator: String,
	prefix: String,
	postfix: String
): String {

	val result = StringBuilder(prefix)

	for (( index, element) in collection.withIndex() ) {
		if ( index > 0 ) result.append(separator)
		result.append(element)
	}

	result.append(postfix)
	return result.toString()
}

fun playWithJoinToStringFunction() {
	val list = listOf(10, 20, 30, 40, 50) // List<Int>
	println( jointToString( list, "; ", " ( ", " ) "))
	println( jointToString( list, ": ", " [ ", " ] "))

	val names = listOf("Alice", "Bob", "Ramesh", "Ganesh", "Aishwaraya") // List<String>
	println( jointToString( names, "; ", " ( ", " ) "))
	println( jointToString( names, ": ", " [ ", " ] "))
	println( jointToString( names, ": ", " <> ", " <> "))
	println( jointToString( names, " ### ", " >>>>>>> ", " <<<<<<< "))

	val arraylist = arrayListOf(1, 7, 53)  // List<Int>
	println( jointToString( arraylist, "; ", " ( ", " ) "))
	println( jointToString( arraylist, ": ", " [ ", " ] "))
	println( jointToString( arraylist, ": ", " <> ", " <> "))
	println( jointToString( arraylist, " ### ", " >>>>>>> ", " <<<<<<< "))

	val namesArray = arrayListOf("Alice", "Bob", "Ramesh", "Ganesh", "Aishwaraya") // List<String>
	println( jointToString( namesArray, "; ", " ( ", " ) "))
	println( jointToString( namesArray, ": ", " [ ", " ] "))
	println( jointToString( namesArray, ": ", " <> ", " <> "))
	println( jointToString( namesArray, " ### ", " >>>>>>> ", " <<<<<<< "))
}


// ______________________________________________________
// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!


fun lastCharacter(string: String) : Char {
	return string.get( string.length - 1 )
}

// Extension Function On String Type
// Adding Functionality To Existing Type String
fun String.lastCharExtension() : Char {
	return this.get( this.length - 1 )
}

fun playWithLastCharacterFunctionAndExtension() {
	var string = "Hello World!"
	println( lastCharacter(string) )
	println ( string.lastCharExtension() )

	string = "Life Is Awesome"
	println( lastCharacter(string) )
	println( string.lastCharExtension() )
}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// Extention Function On Type Collection<T>
fun <T> Collection<T>.jointToStringFinal(
	separator: String = ", ", // Default Values
	prefix: String = "",
	postfix: String = ""
): String {

	val result = StringBuilder(prefix)

	for (( index, element) in this.withIndex() ) {
		if ( index > 0 ) result.append(separator)
		result.append(element)
	}

	result.append(postfix)
	return result.toString()
}

fun playWithJoinToStringFinalExtensionFunction() {
	val list = listOf(10, 20, 30, 40, 50) // List<Int>
	println( list.jointToStringFinal( " ; ", " ( ", " ) "))
	println( list.jointToStringFinal( " : ", " [ ", " ] "))

	val names = listOf("Alice", "Bob", "Ramesh", "Ganesh", "Aishwaraya") // List<String>
	println( names.jointToStringFinal())
	println( names.jointToStringFinal( " : "))
	println( names.jointToStringFinal( " : ", " <> ", " <> "))
	println( names.jointToStringFinal( " ### ", " >>>>>>> ", " <<<<<<< "))

	val arraylist = arrayListOf(1, 7, 53)  // List<Int>
	println( arraylist.jointToStringFinal())
	println( arraylist.jointToStringFinal( " : "))
	println( arraylist.jointToStringFinal( " : ", " <> ", " <> "))
	println( arraylist.jointToStringFinal( " ### ", " >>>>>>> ", " <<<<<<< "))

	val namesArray = arrayListOf("Alice", "Bob", "Ramesh", "Ganesh", "Aishwaraya") // List<String>
	println( namesArray.jointToStringFinal( " ; ", " ( ", " ) "))
	println( namesArray.jointToStringFinal( " : ", " [ ", " ] "))
	println( namesArray.jointToStringFinal( " : ", " <> ", " <> "))
	println( namesArray.jointToStringFinal( " ### ", " >>>>>>> ", " <<<<<<< "))
}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// Extension Function On String Type
// Adding Functionality To Existing Type String
fun String.lastChar() : Char {
	return this.get( this.length - 1 )
}

// Extension Property On String Type
// IMMutable Extension Property
val String.lastChar : Char 
	get() = get( length - 1 )

// Extension Property On StringBuilder Type
// Mutable Extension Property
var StringBuilder.lastChar: Char
	get() = get( length - 1 )
	set(value: Char) {
		this.setCharAt( length - 1, value )
	} 


fun playWithExtensionFunctionsAndProperties() {
	var string = "Hello World!"
	println ( string.lastChar() ) 		// Invoking Extension Function

	string = "Life Is Awesome"
	println( string.lastChar() ) 		// Invoking Extension Function

	println( string.lastChar )			// Accessing Extension Property Getter

	var stringBuild = StringBuilder("Good Morning!")
	println( stringBuild.lastChar )			// Accessing Extension Property Getter
	stringBuild.lastChar = '#'				// Accessing Extension Property Setter
	println( stringBuild.lastChar )			// Accessing Extension Property	Getter

}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

fun calculator(a: Int, b: Int, choice: String) : Int {
	// Local Function : Function Defined Inside Function
	fun sum(x: Int, y: Int ): Int {
		return x + y
	}
	// Local Function : Function Defined Inside Function
	fun sub(x: Int, y: Int): Int {
		return x - y 
	}

	// Following when Expression Code Are Equivalent
	// when(choice) {
	// 	"sum" 	-> 	return sum(a, b)
	// 	"sub" 	-> 	return sub(a, b)
	// 	 else  	-> 	throw Exception("Unknown Choice...")
	// }

	// when is Expression and It Has Return Value
	return when(choice) {
		"sum" 	-> 	sum(a, b)
		"sub" 	-> 	sub(a, b)
		 else  	-> 	throw Exception("Unknown Choice...")
	}
}

fun playWithCalculatorHavingLocalFunctions() {
	val xx = 100
	val yy = 200
	var result : Int
	
	result = calculator(xx, yy, "sum")
	println("Result : $result")

	result = calculator(xx, yy, "sub")
	println("Result : $result")
}

// ______________________________________________________

// ______________________________________________________
// ______________________________________________________
// ______________________________________________________
// ______________________________________________________
// ______________________________________________________
// ______________________________________________________
// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!


fun main() {
	println("\nFunction : playingWithCollectionsInKotlin")
	playingWithCollectionsInKotlin()

	println("\nFunction : playWithHuman")
	playWithHuman()

	println("\nFunction : playWithJoinToStringFunction")
	playWithJoinToStringFunction()

	println("\nFunction : playWithLastCharacterFunctionAndExtension")
	playWithLastCharacterFunctionAndExtension()

	println("\nFunction : playWithJoinToStringFinalExtensionFunction")
	playWithJoinToStringFinalExtensionFunction()

	println("\nFunction : playWithExtensionFunctionsAndProperties")
	playWithExtensionFunctionsAndProperties()

	println("\nFunction :playWithCalculatorHavingLocalFunctions ")
	playWithCalculatorHavingLocalFunctions()
	
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

